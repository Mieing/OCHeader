@interface JSC2TimeZoneUtil : NSObject

+ (BOOL)is24Hours;
+ (void)resetTimezone;
+ (void)setup;
+ (void)timeZoneChanged:(id)a0;

@end
