@interface JSScript2 : NSObject {
    struct WeakObjCPtr<JSVirtualMachine2> { id m_weakReference; } m_virtualMachine;
    long long m_type;
    struct MappedFileData { void *m_fileData; unsigned int m_fileSize; unsigned int m_paddingSize; int m_padding; } m_mappedSource;
    struct String { struct RefPtr<WTF2::StringImpl, WTF2::RawPtrTraits<WTF2::StringImpl>, WTF2::DefaultRefDerefTraits<WTF2::StringImpl>> { struct StringImpl *m_ptr; } m_impl; } m_source;
    struct RetainPtr<NSURL> { void *m_ptr; } m_sourceURL;
    struct RetainPtr<NSURL> { void *m_ptr; } m_cachePath;
    struct RefPtr<JSC2::CachedBytecode, WTF2::RawPtrTraits<JSC2::CachedBytecode>, WTF2::DefaultRefDerefTraits<JSC2::CachedBytecode>> { struct CachedBytecode *m_ptr; } m_cachedBytecode;
    unsigned long long m_cachedHash;
    unsigned long long m_version;
    unsigned long long m_codeCacheSize;
    struct array<unsigned char, 20UL> { unsigned char __elems_[20]; } m_digest;
    long long m_err;
    BOOL m_hasCache;
    char m_flag;
}

+ (id)scriptOfType:(long long)a0 withScript:(void *)a1 andSourceURL:(id)a2 andBytecodeCache:(id)a3 inVirtualMachine:(id)a4 error:(out id *)a5;
+ (id)scriptOfType:(long long)a0 memoryMappedFromASCIIFile:(id)a1 withSourceURL:(id)a2 andBytecodeCache:(id)a3 inVirtualMachine:(id)a4 error:(out id *)a5;
+ (id)scriptOfType:(long long)a0 withSource:(id)a1 andSourceURL:(id)a2 andBytecodeCache:(id)a3 inVirtualMachine:(id)a4 error:(out id *)a5;

- (id)hashName;
- (void)setHashName:(id)a0;
- (BOOL)isBytecodeValid:(long long *)a0;
- (BOOL)isBytecodeValid;
- (unsigned long long)codeCacheSize;
- (void)readCache;
- (long long)errorCode;
- (id)cacheURL;
- (void).cxx_destruct;
- (BOOL)validate;
- (const void *)source;
- (id)sourceURL;
- (unsigned long long)version;
- (struct SourceCode { struct RefPtr<JSC2::SourceProvider, WTF2::RawPtrTraits<JSC2::SourceProvider>, WTF2::DefaultRefDerefTraits<JSC2::SourceProvider>> { struct SourceProvider *x0; } x0; int x1; int x2; struct OrdinalNumber { int x0; } x3; struct OrdinalNumber { int x0; } x4; })sourceCode;
- (id)init;
- (long long)type;
- (struct RefPtr<JSC2::CachedBytecode, WTF2::RawPtrTraits<JSC2::CachedBytecode>, WTF2::DefaultRefDerefTraits<JSC2::CachedBytecode>> { struct CachedBytecode *x0; })cachedBytecode;
- (BOOL)isUsingBytecodeCache;
- (id).cxx_construct;
- (unsigned int)hash;
- (void *)jsSourceCode;
- (BOOL)cacheBytecodeWithError:(id *)a0;
- (id)virtualMachine;
- (BOOL)writeCache:(void *)a0;

@end
