@interface JSVMWrapperCache2 : NSObject

+ (void)addWrapper:(id)a0 forJSContextGroupRef:(struct OpaqueJSContextGroup { } *)a1;
+ (id)wrapperForJSContextGroupRef:(struct OpaqueJSContextGroup { } *)a0;

@end
