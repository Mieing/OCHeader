@class JSValue2;

@interface JSManagedValue2 : NSObject {
    struct Weak<JSC2::JSGlobalObject> { struct WeakImpl *m_impl; } m_globalObject;
    struct RefPtr<JSC2::JSLock, WTF2::RawPtrTraits<JSC2::JSLock>, WTF2::DefaultRefDerefTraits<JSC2::JSLock>> { struct JSLock *m_ptr; } m_lock;
    struct JSWeakValue { int m_tag; union WeakValueUnion { struct JSValue { union EncodedValueDescriptor { long long asInt64; struct JSCell *ptr; struct { int payload; int tag; } asBits; } u; } primitive; struct Weak<JSC2::JSObject> { struct WeakImpl *m_impl; } object; struct Weak<JSC2::JSString> { struct WeakImpl *m_impl; } string; } m_value; } m_weakValue;
    struct RetainPtr<NSMapTable> { void *m_ptr; } m_owners;
}

@property (readonly) JSValue2 *value;

+ (id)managedValueWithValue:(id)a0;
+ (id)managedValueWithValue:(id)a0 andOwner:(id)a1;

- (void).cxx_destruct;
- (void)didRemoveOwner:(id)a0;
- (id)init;
- (id).cxx_construct;
- (void)disconnectValue;
- (id)initWithValue:(id)a0;
- (void)dealloc;
- (void)didAddOwner:(id)a0;

@end
