@interface JSObjCClassInfo2 : NSObject {
    Class m_class;
    BOOL m_block;
    struct NakedPtr<OpaqueJSClass> { struct OpaqueJSClass *m_ptr; } m_classRef;
    struct Weak<JSC2::JSObject> { struct WeakImpl *m_impl; } m_prototype;
    struct Weak<JSC2::JSObject> { struct WeakImpl *m_impl; } m_constructor;
    struct Weak<JSC2::Structure> { struct WeakImpl *m_impl; } m_structure;
}

- (void).cxx_destruct;
- (struct pair<JSC2::JSObject *, JSC2::JSObject *> { struct JSObject *x0; struct JSObject *x1; })allocateConstructorAndPrototypeInContext:(id)a0;
- (id).cxx_construct;
- (id)initForClass:(Class)a0;
- (void *)structureInContext:(id)a0;
- (void *)wrapperForObject:(id)a0 inContext:(id)a1;
- (void *)constructorInContext:(id)a0;
- (void *)prototypeInContext:(id)a0;
- (void)dealloc;

@end
