@class JSVirtualMachine2, NSString, JSValue2;

@interface JSContext2 : NSObject {
    struct RetainPtr<JSVirtualMachine2> { void *m_ptr; } m_virtualMachine;
    struct OpaqueJSContext { } *m_context;
    struct Strong<JSC2::JSObject, JSC2::ShouldStrongDestructorGrabLock::No> { struct JSValue *m_slot; } m_exception;
    struct WeakObjCPtr<id<JSModuleLoaderDelegate>> { id m_weakReference; } m_moduleLoaderDelegate;
}

@property (readonly) JSValue2 *globalObject;
@property (retain) JSValue2 *exception;
@property (copy) id /* block */ exceptionHandler;
@property (readonly) JSVirtualMachine2 *virtualMachine;
@property (copy) NSString *name;
@property (nonatomic, getter=isInspectable) BOOL inspectable;

+ (id)currentContext;
+ (id)currentArguments;
+ (id)currentCallee;
+ (id)contextWithJSGlobalContextRef:(struct OpaqueJSContext { } *)a0;
+ (id)currentThis;

- (id)bytecodeMap;
- (id)nameForScript:(id)a0 codeCacheSource:(id)a1;
- (id)cachePathForName:(id)a0 codeCacheSource:(id)a1;
- (id)codecacheDirPathForSource:(id)a0;
- (BOOL)byteCodeEnabledForScript:(id)a0 codeCacheSource:(id)a1;
- (id)mm_setupBytecode:(id)a0 sourceURL:(id)a1 inVirtualMachine:(id)a2;
- (void)validationCodeCacheForJSSourceScript:(id)a0 sourceURL:(id)a1 codeCacheSource:(id)a2;
- (void)createCodeCacheIfNeededForJSScript:(id)a0;
- (void)didCreateCodeCacheForJSSCript:(id)a0;
- (void)logError:(id)a0;
- (id)mm_evaluateScript:(id)a0 withSourceURL:(id)a1;
- (id)jwd_init;
- (id)jwd_initWithVirtualMachine:(id)a0;
- (void)jwd_setName:(id)a0;
- (id)wrapperForObjCObject:(id)a0;
- (void).cxx_destruct;
- (void)setModuleLoaderDelegate:(id)a0;
- (id)evaluateScript:(id)a0 withSourceURL:(id)a1;
- (void)beginCallbackWithData:(void *)a0 calleeValue:(struct OpaqueJSValue { } *)a1 thisValue:(struct OpaqueJSValue { } *)a2 argumentCount:(unsigned long long)a3 arguments:(const struct OpaqueJSValue **)a4;
- (id)moduleLoaderDelegate;
- (void)_setIncludesNativeCallStackWhenReportingExceptions:(BOOL)a0;
- (void)endCallbackWithData:(void *)a0;
- (id)dependencyIdentifiersForModuleJSScript:(id)a0;
- (id)evaluateScript:(id)a0;
- (id)init;
- (id)wrapperForJSObject:(struct OpaqueJSValue { } *)a0;
- (void)_setDebuggerRunLoop:(struct __CFRunLoop { } *)a0;
- (id)initWithVirtualMachine:(id)a0;
- (void)ensureWrapperMap;
- (id)initWithGlobalContextRef:(struct OpaqueJSContext { } *)a0;
- (id)objectForKeyedSubscript:(id)a0;
- (BOOL)_includesNativeCallStackWhenReportingExceptions;
- (void)_setITMLDebuggableType;
- (id).cxx_construct;
- (void)setObject:(id)a0 forKeyedSubscript:(id)a1;
- (id)valueFromNotifyException:(struct OpaqueJSValue { } *)a0;
- (struct OpaqueJSContext { } *)JSGlobalContextRef;
- (void)notifyException:(struct OpaqueJSValue { } *)a0;
- (BOOL)boolFromNotifyException:(struct OpaqueJSValue { } *)a0;
- (BOOL)_remoteInspectionEnabled;
- (id)wrapperMap;
- (struct __CFRunLoop { } *)_debuggerRunLoop;
- (void)dealloc;
- (id)evaluateJSScript:(id)a0;
- (void)_setRemoteInspectionEnabled:(BOOL)a0;

@end
