@interface LOTCacheProvider : NSObject

+ (id)imageCache;
+ (void)setImageCache:(id)a0;

@end
