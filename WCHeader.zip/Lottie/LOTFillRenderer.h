@class CALayer, LOTNumberInterpolator, LOTColorInterpolator;

@interface LOTFillRenderer : LOTRenderNode {
    LOTColorInterpolator *colorInterpolator_;
    LOTNumberInterpolator *opacityInterpolator_;
    BOOL _evenOddFillRule;
    CALayer *centerPoint_DEBUG;
}

- (id)actionsForRenderLayer;
- (id)initWithInputNode:(id)a0 shapeFill:(id)a1;
- (BOOL)needsUpdateForFrame:(id)a0;
- (void)performLocalUpdate;
- (void)rebuildOutputs;
- (id)valueInterpolators;
- (void).cxx_destruct;

@end
