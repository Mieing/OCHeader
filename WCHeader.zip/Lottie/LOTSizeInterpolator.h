@protocol LOTSizeValueDelegate;

@interface LOTSizeInterpolator : LOTValueInterpolator

@property (weak, nonatomic) id<LOTSizeValueDelegate> delegate;

- (BOOL)hasDelegateOverride;
- (void)setValueDelegate:(id)a0;
- (struct CGSize { double x0; double x1; })sizeValueForFrame:(id)a0;
- (void).cxx_destruct;

@end
