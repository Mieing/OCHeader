@protocol LOTColorValueDelegate;

@interface LOTColorInterpolator : LOTValueInterpolator

@property (weak, nonatomic) id<LOTColorValueDelegate> delegate;

- (struct CGColor { } *)colorForFrame:(id)a0;
- (BOOL)hasDelegateOverride;
- (void)setValueDelegate:(id)a0;
- (void).cxx_destruct;

@end
