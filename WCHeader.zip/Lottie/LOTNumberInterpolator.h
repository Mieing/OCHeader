@protocol LOTNumberValueDelegate;

@interface LOTNumberInterpolator : LOTValueInterpolator

@property (weak, nonatomic) id<LOTNumberValueDelegate> delegate;

- (double)floatValueForFrame:(id)a0;
- (BOOL)hasDelegateOverride;
- (void)setValueDelegate:(id)a0;
- (void).cxx_destruct;

@end
