@class LOTShapePath, LOTPathInterpolator;

@interface LOTPathAnimator : LOTAnimatorNode {
    LOTShapePath *_pathConent;
    LOTPathInterpolator *_interpolator;
}

- (id)initWithInputNode:(id)a0 shapePath:(id)a1;
- (BOOL)needsUpdateForFrame:(id)a0;
- (void)performLocalUpdate;
- (id)valueInterpolators;
- (void).cxx_destruct;

@end
