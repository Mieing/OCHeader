@class NSArray, LOTNumberInterpolator, LOTColorInterpolator;

@interface LOTStrokeRenderer : LOTRenderNode {
    LOTColorInterpolator *_colorInterpolator;
    LOTNumberInterpolator *_opacityInterpolator;
    LOTNumberInterpolator *_widthInterpolator;
    LOTNumberInterpolator *_dashOffsetInterpolator;
    NSArray *_dashPatternInterpolators;
}

- (void)_updateLineDashPatternsForFrame:(id)a0;
- (id)actionsForRenderLayer;
- (id)initWithInputNode:(id)a0 shapeStroke:(id)a1;
- (BOOL)needsUpdateForFrame:(id)a0;
- (void)performLocalUpdate;
- (void)rebuildOutputs;
- (id)valueInterpolators;
- (void).cxx_destruct;

@end
