@class CAShapeLayer;

@interface LOTRenderNode : LOTAnimatorNode

@property (readonly, nonatomic) CAShapeLayer *outputLayer;

- (id)actionsForRenderLayer;
- (id)initWithInputNode:(id)a0 keyName:(id)a1;
- (void)performLocalUpdate;
- (void)rebuildOutputs;
- (void).cxx_destruct;
- (id)localPath;
- (id)outputPath;

@end
