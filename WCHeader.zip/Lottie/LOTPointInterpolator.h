@protocol LOTPointValueDelegate;

@interface LOTPointInterpolator : LOTValueInterpolator

@property (weak, nonatomic) id<LOTPointValueDelegate> delegate;

- (BOOL)hasDelegateOverride;
- (struct CGPoint { double x0; double x1; })pointValueForFrame:(id)a0;
- (void)setValueDelegate:(id)a0;
- (void).cxx_destruct;

@end
