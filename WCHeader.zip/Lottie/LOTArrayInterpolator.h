@interface LOTArrayInterpolator : LOTValueInterpolator

- (id)numberArrayForFrame:(id)a0;

@end
