@protocol LOTPathValueDelegate;

@interface LOTPathInterpolator : LOTValueInterpolator

@property (weak, nonatomic) id<LOTPathValueDelegate> delegate;

- (BOOL)hasDelegateOverride;
- (id)pathForFrame:(id)a0 cacheLengths:(BOOL)a1;
- (void)setValueDelegate:(id)a0;
- (void).cxx_destruct;

@end
