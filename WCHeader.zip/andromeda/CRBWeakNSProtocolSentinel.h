@interface CRBWeakNSProtocolSentinel : NSObject

@property (readonly) struct scoped_refptr<base::WeakContainer> { struct WeakContainer *ptr_; } container;

+ (struct scoped_refptr<base::WeakContainer> { struct WeakContainer *x0; })containerForObject:(id)a0;

- (id)initWithContainer:(struct scoped_refptr<base::WeakContainer> { struct WeakContainer *x0; })a0;
- (void)dealloc;
- (void).cxx_destruct;
- (id).cxx_construct;

@end
