@class __end_, __end_cap_, Protocol;

@interface CRBProtocolObservers : NSObject {
    Protocol *_protocol;
    struct vector<__weak id, std::allocator<__weak id>> { __end_ **__begin_; __end_cap_ **x0; struct __compressed_pair<__weak id *, std::allocator<__weak id>> { id *__value_; } x1; } _observers;
    int _invocationDepth;
}

@property (readonly, nonatomic) Protocol *protocol;

+ (id)observersWithProtocol:(id)a0;

- (void)executeOnObservers:(id /* block */)a0;
- (void)compact;
- (BOOL)empty;
- (void).cxx_destruct;
- (void)addObserver:(id)a0;
- (id)initWithProtocol:(id)a0;
- (id)init;
- (id)methodSignatureForSelector:(SEL)a0;
- (id).cxx_construct;
- (void)removeObserver:(id)a0;
- (void)forwardInvocation:(id)a0;

@end
