@class NSString;

@interface CDSemanticStringStaple : NSObject

@property (retain, nonatomic) NSString *string;
@property (nonatomic) unsigned long long type;

- (void).cxx_destruct;

@end
