@class CDParseType;

@interface CDArrayType : CDParseType

@property (retain, nonatomic) CDParseType *type;
@property (nonatomic) unsigned long long size;

- (id)semanticStringForVariableName:(id)a0;
- (id)classReferences;
- (id)protocolReferences;
- (BOOL)isEqual:(id)a0;
- (id)debugDescription;
- (void).cxx_destruct;

@end
