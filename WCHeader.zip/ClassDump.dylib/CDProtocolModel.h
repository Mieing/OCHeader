@class NSString, NSArray, Protocol;

@interface CDProtocolModel : NSObject {
    NSArray *_classPropertySynthesizedMethods;
    NSArray *_instancePropertySynthesizedMethods;
}

@property (readonly, nonatomic) Protocol *backing;
@property (readonly, nonatomic) NSString *name;
@property (readonly, nonatomic) NSArray *protocols;
@property (readonly, nonatomic) NSArray *requiredClassProperties;
@property (readonly, nonatomic) NSArray *requiredInstanceProperties;
@property (readonly, nonatomic) NSArray *requiredClassMethods;
@property (readonly, nonatomic) NSArray *requiredInstanceMethods;
@property (readonly, nonatomic) NSArray *optionalClassProperties;
@property (readonly, nonatomic) NSArray *optionalInstanceProperties;
@property (readonly, nonatomic) NSArray *optionalClassMethods;
@property (readonly, nonatomic) NSArray *optionalInstanceMethods;

+ (id)requiredClassPropertiesToConform:(id)a0;
+ (id)requiredInstancePropertiesToConform:(id)a0;
+ (id)requiredClassMethodsToConform:(id)a0;
+ (id)requiredInstanceMethodsToConform:(id)a0;
+ (id)_genericRequiredForConformance:(id)a0 property:(SEL)a1 identifiable:(id /* block */)a2;
+ (void)_genericRequiredForConformance:(id)a0 build:(id)a1 tracking:(id)a2 property:(SEL)a3 identifiable:(id /* block */)a4;
+ (id)modelWithProtocol:(id)a0;

- (id)initWithProtocol:(id)a0;
- (id)linesWithComments:(BOOL)a0 synthesizeStrip:(BOOL)a1;
- (id)semanticLinesWithComments:(BOOL)a0 synthesizeStrip:(BOOL)a1;
- (id)semanticLinesWithOptions:(id)a0;
- (void)_appendLines:(id)a0 properties:(id)a1 comments:(BOOL)a2;
- (void)_appendLines:(id)a0 methods:(id)a1 synthesized:(id)a2 comments:(BOOL)a3;
- (id)_forwardDeclarableClassReferences;
- (id)_forwardDeclarableProtocolReferences;
- (id)classReferences;
- (id)protocolReferences;
- (void)_unionReferences:(id)a0 sources:(id)a1 resolve:(id /* block */)a2;
- (id)description;
- (id)debugDescription;
- (void).cxx_destruct;

@end
