@interface CDPrimitiveType : CDParseType

@property (nonatomic) unsigned long long rawType;

+ (id)primitiveWithRawType:(unsigned long long)a0;

- (id)semanticStringForVariableName:(id)a0;
- (BOOL)isEqual:(id)a0;
- (id)debugDescription;

@end
