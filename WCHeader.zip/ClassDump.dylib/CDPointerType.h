@class CDParseType;

@interface CDPointerType : CDParseType

@property (retain, nonatomic) CDParseType *pointee;

+ (id)pointerToPointee:(id)a0;

- (id)semanticStringForVariableName:(id)a0;
- (id)classReferences;
- (id)protocolReferences;
- (BOOL)isEqual:(id)a0;
- (id)debugDescription;
- (void).cxx_destruct;

@end
