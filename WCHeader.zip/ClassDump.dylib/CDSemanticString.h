@class NSMutableArray;

@interface CDSemanticString : NSObject {
    NSMutableArray *_components;
}

@property (readonly) unsigned long long length;

- (id)init;
- (void)appendSemanticString:(id)a0;
- (void)appendString:(id)a0 semanticType:(unsigned long long)a1;
- (BOOL)startsWithChar:(char)a0;
- (BOOL)endWithChar:(char)a0;
- (void)enumerateTypesUsingBlock:(id /* block */)a0;
- (void)enumerateLongestEffectiveRangesUsingBlock:(id /* block */)a0;
- (id)string;
- (void).cxx_destruct;

@end
