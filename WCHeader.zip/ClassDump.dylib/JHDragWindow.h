@interface JHDragWindow : UIWindow

+ (id)sharedWindow;
+ (void)showWindow;
+ (void)hideWindow;

@end
