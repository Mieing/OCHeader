@class CDParseType, NSArray;

@interface CDBlockType : CDParseType

@property (retain, nonatomic) CDParseType *returnType;
@property (retain, nonatomic) NSArray *parameterTypes;

- (id)semanticStringForVariableName:(id)a0;
- (id)classReferences;
- (id)protocolReferences;
- (BOOL)isEqual:(id)a0;
- (id)debugDescription;
- (void).cxx_destruct;

@end
