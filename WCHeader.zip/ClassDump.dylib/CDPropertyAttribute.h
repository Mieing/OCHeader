@class NSString;

@interface CDPropertyAttribute : NSObject

@property (readonly, nonatomic) NSString *name;
@property (readonly, nonatomic) NSString *value;

+ (id)attributeWithName:(id)a0 value:(id)a1;

- (id)initWithName:(id)a0 value:(id)a1;
- (BOOL)isEqual:(id)a0;
- (id)description;
- (id)debugDescription;
- (void).cxx_destruct;

@end
