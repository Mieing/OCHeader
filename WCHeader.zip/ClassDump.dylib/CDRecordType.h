@class NSString, NSArray;

@interface CDRecordType : CDParseType

@property (retain, nonatomic) NSString *name;
@property (nonatomic) BOOL isUnion;
@property (retain, nonatomic) NSArray *fields;

- (id)semanticStringForVariableName:(id)a0;
- (id)classReferences;
- (id)protocolReferences;
- (BOOL)isEqual:(id)a0;
- (id)debugDescription;
- (void).cxx_destruct;

@end
