@class NSArray;

@interface CDParseType : NSObject

@property (retain, nonatomic) NSArray *modifiers;

- (id)stringForVariableName:(id)a0;
- (id)semanticStringForVariableName:(id)a0;
- (id)modifiersString;
- (id)modifiersSemanticString;
- (id)classReferences;
- (id)protocolReferences;
- (BOOL)isEqual:(id)a0;
- (id)description;
- (id)debugDescription;
- (void).cxx_destruct;

@end
