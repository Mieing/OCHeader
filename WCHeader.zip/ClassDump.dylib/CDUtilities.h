@interface CDUtilities : NSObject

+ (id)dyldSharedCacheImagePaths;
+ (id)classNames;
+ (BOOL)isClassSafeToInspect:(id)a0;

@end
