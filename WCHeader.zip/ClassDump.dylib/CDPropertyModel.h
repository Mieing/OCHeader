@class NSString, CDParseType, NSArray;

@interface CDPropertyModel : NSObject

@property (readonly, nonatomic) struct objc_property { } *backing;
@property (readonly, nonatomic) NSString *name;
@property (readonly, nonatomic) CDParseType *type;
@property (readonly, nonatomic) NSArray *attributes;
@property (readonly, nonatomic) NSString *iVar;
@property (readonly, nonatomic) NSString *getter;
@property (readonly, nonatomic) NSString *setter;

+ (id)modelWithProperty:(struct objc_property { } *)a0 isClass:(BOOL)a1;

- (id)initWithProperty:(struct objc_property { } *)a0 isClass:(BOOL)a1;
- (void)overrideType:(id)a0;
- (id)semanticString;
- (BOOL)isEqual:(id)a0;
- (unsigned long long)hash;
- (id)description;
- (id)debugDescription;
- (void).cxx_destruct;

@end
