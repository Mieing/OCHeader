@interface CDBitFieldType : CDParseType

@property (nonatomic) unsigned long long width;

- (id)semanticStringForVariableName:(id)a0;
- (BOOL)isEqual:(id)a0;
- (id)debugDescription;

@end
