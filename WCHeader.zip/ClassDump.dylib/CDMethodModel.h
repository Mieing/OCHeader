@class NSString, NSArray, CDParseType;

@interface CDMethodModel : NSObject

@property (readonly, nonatomic) struct objc_method_description { SEL name; char *types; } backing;
@property (readonly, nonatomic) NSString *name;
@property (readonly, nonatomic) NSArray *argumentTypes;
@property (readonly, nonatomic) CDParseType *returnType;
@property (readonly, nonatomic) BOOL isClass;

+ (id)modelWithMethod:(struct objc_method_description { SEL x0; char *x1; })a0 isClass:(BOOL)a1;

- (id)initWithMethod:(struct objc_method_description { SEL x0; char *x1; })a0 isClass:(BOOL)a1;
- (id)semanticString;
- (id)classReferences;
- (id)protocolReferences;
- (BOOL)isEqual:(id)a0;
- (unsigned long long)hash;
- (id)description;
- (id)debugDescription;
- (void).cxx_destruct;

@end
