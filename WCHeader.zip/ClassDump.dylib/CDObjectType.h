@class NSString, NSArray;

@interface CDObjectType : CDParseType

@property (retain, nonatomic) NSString *className;
@property (retain, nonatomic) NSArray *protocolNames;

- (id)semanticStringForVariableName:(id)a0;
- (id)classReferences;
- (id)protocolReferences;
- (BOOL)isEqual:(id)a0;
- (id)debugDescription;
- (void).cxx_destruct;

@end
