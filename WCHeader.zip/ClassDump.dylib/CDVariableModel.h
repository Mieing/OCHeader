@class NSString, CDParseType;

@interface CDVariableModel : NSObject

@property (retain, nonatomic) NSString *name;
@property (retain, nonatomic) CDParseType *type;

- (BOOL)isEqual:(id)a0;
- (id)description;
- (id)debugDescription;
- (void).cxx_destruct;

@end
