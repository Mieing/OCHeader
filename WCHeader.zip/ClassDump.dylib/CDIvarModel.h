@class NSString, CDParseType;

@interface CDIvarModel : NSObject

@property (readonly, nonatomic) struct objc_ivar { } *backing;
@property (readonly, nonatomic) NSString *name;
@property (readonly, nonatomic) CDParseType *type;

+ (id)modelWithIvar:(struct objc_ivar { } *)a0;

- (id)initWithIvar:(struct objc_ivar { } *)a0;
- (id)semanticString;
- (BOOL)isEqual:(id)a0;
- (id)description;
- (void).cxx_destruct;

@end
