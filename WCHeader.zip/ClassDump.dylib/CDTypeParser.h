@interface CDTypeParser : NSObject

+ (const char *)endOfTypeEncoding:(const char *)a0;
+ (id)typeForEncoding:(const char *)a0;
+ (id)typeForEncodingStart:(const char *)a0 end:(const char *)a1 error:(inout BOOL *)a2;
+ (id)recordTypeForEncodingStart:(const char *)a0 end:(const char *)a1;

@end
