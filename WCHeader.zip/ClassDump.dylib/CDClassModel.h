@class NSString, NSArray;

@interface CDClassModel : NSObject {
    NSArray *_classPropertySynthesizedMethods;
    NSArray *_instancePropertySynthesizedMethods;
    NSArray *_instancePropertySynthesizedVars;
}

@property (readonly, nonatomic) Class backing;
@property (readonly, nonatomic) NSString *name;
@property (readonly, nonatomic) NSArray *protocols;
@property (readonly, nonatomic) NSArray *classProperties;
@property (readonly, nonatomic) NSArray *instanceProperties;
@property (readonly, nonatomic) NSArray *classMethods;
@property (readonly, nonatomic) NSArray *instanceMethods;
@property (readonly, nonatomic) NSArray *ivars;

+ (id)modelWithClass:(Class)a0;

- (id)initWithClass:(Class)a0;
- (id)linesWithComments:(BOOL)a0 synthesizeStrip:(BOOL)a1;
- (id)semanticLinesWithComments:(BOOL)a0 synthesizeStrip:(BOOL)a1;
- (id)semanticLinesWithOptions:(id)a0;
- (void)_appendLines:(id)a0 properties:(id)a1 comments:(BOOL)a2;
- (void)_appendLines:(id)a0 methods:(id)a1 synthesized:(id)a2 comments:(BOOL)a3 stripCtor:(BOOL)a4 stripDtor:(BOOL)a5;
- (id)_forwardDeclarableClassReferences;
- (id)_forwardDeclarableProtocolReferences;
- (id)classReferences;
- (id)protocolReferences;
- (void)_unionReferences:(id)a0 sources:(id)a1 resolve:(id /* block */)a2;
- (id)description;
- (id)debugDescription;
- (void).cxx_destruct;

@end
