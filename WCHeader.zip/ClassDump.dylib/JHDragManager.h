@interface JHDragManager : NSObject

+ (void)addDragViewIfNeeded;

@end
