@class UIProgressView, NSString, UILabel, UIView, UIViewController;

@interface ClassDumper : NSObject <SSZipArchiveDelegate>

@property (retain, nonatomic) UIProgressView *progressView;
@property (retain, nonatomic) UILabel *progressLabel;
@property (retain, nonatomic) UIView *overlay;
@property (copy, nonatomic) NSString *zipPath;
@property (weak, nonatomic) UIViewController *vc;
@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

+ (id)dumpClasses;
+ (void)dumpClassesAsyncWithViewController:(id)a0;

- (void).cxx_destruct;

@end
