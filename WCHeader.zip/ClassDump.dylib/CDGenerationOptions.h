@interface CDGenerationOptions : NSObject

@property (nonatomic) BOOL stripProtocolConformance;
@property (nonatomic) BOOL stripOverrides;
@property (nonatomic) BOOL stripDuplicates;
@property (nonatomic) BOOL stripSynthesized;
@property (nonatomic) BOOL stripCtorMethod;
@property (nonatomic) BOOL stripDtorMethod;
@property (nonatomic) BOOL addSymbolImageComments;

@end
