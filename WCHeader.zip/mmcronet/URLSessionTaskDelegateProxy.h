@class NSString;
@protocol NSURLSessionDelegate;

@interface URLSessionTaskDelegateProxy : NSProxy <NSURLSessionTaskDelegate> {
    id<NSURLSessionDelegate> _delegate;
    BOOL _respondsToDidFinishCollectingMetrics;
}

@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

- (void).cxx_destruct;
- (id)initWithDelegate:(id)a0;
- (id)methodSignatureForSelector:(SEL)a0;
- (void)URLSession:(id)a0 task:(id)a1 didFinishCollectingMetrics:(id)a2;
- (BOOL)respondsToSelector:(SEL)a0;
- (void)forwardInvocation:(id)a0;

@end
