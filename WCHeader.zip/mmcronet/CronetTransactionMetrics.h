@class NSString, NSURLResponse, NSDate, NSURLRequest;

@interface CronetTransactionMetrics : NSURLSessionTaskTransactionMetrics

@property (copy) NSURLRequest *request;
@property (copy) NSURLResponse *response;
@property (copy) NSDate *fetchStartDate;
@property (copy) NSDate *domainLookupStartDate;
@property (copy) NSDate *domainLookupEndDate;
@property (copy) NSDate *connectStartDate;
@property (copy) NSDate *secureConnectionStartDate;
@property (copy) NSDate *secureConnectionEndDate;
@property (copy) NSDate *connectEndDate;
@property (copy) NSDate *requestStartDate;
@property (copy) NSDate *requestEndDate;
@property (copy) NSDate *responseStartDate;
@property (copy) NSDate *responseEndDate;
@property (copy) NSString *networkProtocolName;
@property (getter=isProxyConnection) BOOL proxyConnection;
@property (getter=isReusedConnection) BOOL reusedConnection;
@property long long resourceFetchType;

- (void).cxx_destruct;
- (id)description;
- (id)init;

@end
