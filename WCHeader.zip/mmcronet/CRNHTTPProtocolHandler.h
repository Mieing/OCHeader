@class NSThread, NSURLSessionTask;
@protocol CRNHTTPProtocolHandlerProxy;

@interface CRNHTTPProtocolHandler : NSURLProtocol {
    struct scoped_refptr<net::HttpProtocolHandlerCore> { struct HttpProtocolHandlerCore *ptr_; } _core;
    id<CRNHTTPProtocolHandlerProxy> _protocolProxy;
    NSThread *_clientThread;
    BOOL _supportedURL;
    NSURLSessionTask *_task;
}

+ (BOOL)canInitWithRequest:(id)a0;
+ (id)canonicalRequestForRequest:(id)a0;

- (void)ensureProtocolHandlerProxyCreated;
- (void).cxx_destruct;
- (void)startLoading;
- (id).cxx_construct;
- (id)cachedResponse;
- (void)stopLoading;
- (void)cancelRequest;
- (id)initWithTask:(id)a0 cachedResponse:(id)a1 client:(id)a2;
- (id)initWithRequest:(id)a0 cachedResponse:(id)a1 client:(id)a2;

@end
