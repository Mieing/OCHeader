@class NSArray;

@interface CronetMetrics : NSURLSessionTaskMetrics

@property (copy) NSArray *transactionMetrics;

- (void).cxx_destruct;
- (id)init;

@end
