@interface DeferredCancellation : NSObject {
    struct scoped_refptr<net::HttpProtocolHandlerCore> { struct HttpProtocolHandlerCore *ptr_; } _core;
}

- (id)initWithCore:(struct scoped_refptr<net::HttpProtocolHandlerCore> { struct HttpProtocolHandlerCore *x0; })a0;
- (void).cxx_destruct;
- (id).cxx_construct;
- (void)cancel;

@end
