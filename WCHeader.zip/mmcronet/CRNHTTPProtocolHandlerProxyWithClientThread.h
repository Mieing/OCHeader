@class NSString, NSThread, NSURLProtocol, NSArray, NSMutableArray;

@interface CRNHTTPProtocolHandlerProxyWithClientThread : NSObject <CRNHTTPProtocolHandlerProxy> {
    NSURLProtocol *_protocol;
    NSThread *_clientThread;
    NSArray *_runLoopModes;
    NSString *_url;
    struct Time { struct ClampedNumeric<long long> { long long value_; } us_; } _creationTime;
    BOOL _requestComplete;
    BOOL _paused;
    NSMutableArray *_queuedBlocks;
}

@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

- (void)wasRedirectedToRequest:(id)a0 nativeRequest:(void *)a1 redirectResponse:(id)a2;
- (void)didFailWithNSErrorCode:(long long)a0 netErrorCode:(int)a1;
- (void)didCreateNativeRequest:(void *)a0;
- (id)initWithProtocol:(id)a0 clientThread:(id)a1 runLoopMode:(id)a2;
- (void)didFailWithErrorOnClientThread:(id)a0;
- (void)postBlockToClientThread:(id /* block */)a0;
- (void)didLoadDataOnClientThread:(id)a0;
- (void)didReceiveResponseOnClientThread:(id)a0;
- (void)wasRedirectedToRequestOnClientThread:(id)a0 redirectResponse:(id)a1;
- (void)didFinishLoadingOnClientThread;
- (void)runQueuedBlocksOnClientThread;
- (void)didFinishLoading;
- (void).cxx_destruct;
- (void)pause;
- (void)invalidate;
- (void)didReceiveResponse:(id)a0;
- (id).cxx_construct;
- (void)resume;
- (void)didLoadData:(id)a0;
- (void)performBlockOnClientThread:(id /* block */)a0;

@end
