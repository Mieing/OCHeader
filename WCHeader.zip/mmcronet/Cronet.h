@interface Cronet : NSObject

+ (id)getUserAgent;
+ (id)getAcceptLanguagesFromPreferredLanguages:(id)a0;
+ (void)checkNotStarted;
+ (id)getNetLogPathForFile:(id)a0;
+ (id)createUnsupportedConfigurationError:(id)a0;
+ (id)createIllegalArgumentErrorWithArgument:(id)a0 reason:(id)a1;
+ (id)getAcceptLanguages;
+ (void)configureCronetEnvironmentForTesting:(void *)a0;
+ (void)unswizzleForTesting;
+ (id)createCronetErrorWithCode:(int)a0 userInfo:(id)a1;
+ (void)setAcceptLanguages:(id)a0;
+ (void)setHttp2Enabled:(BOOL)a0;
+ (void)setQuicEnabled:(BOOL)a0;
+ (void)setBrotliEnabled:(BOOL)a0;
+ (BOOL)addQuicHint:(id)a0 port:(int)a1 altPort:(int)a2;
+ (void)setExperimentalOptions:(id)a0;
+ (void)setUserAgent:(id)a0 partial:(BOOL)a1;
+ (void)setSslKeyLogFileName:(id)a0;
+ (void)setHttpCacheType:(long long)a0;
+ (void)setRequestFilterBlock:(id /* block */)a0;
+ (BOOL)addPublicKeyPinsForHost:(id)a0 pinHashes:(id)a1 includeSubdomains:(BOOL)a2 expirationDate:(id)a3 error:(id *)a4;
+ (void)setEnablePublicKeyPinningBypassForLocalTrustAnchors:(BOOL)a0;
+ (void *)getFileThreadRunnerForTesting;
+ (void *)getNetworkThreadRunnerForTesting;
+ (void)shutdownForTesting;
+ (void)registerHttpProtocolHandler;
+ (void)unregisterHttpProtocolHandler;
+ (void)installIntoSessionConfiguration:(id)a0;
+ (BOOL)startNetLogToFile:(id)a0 logBytes:(BOOL)a1;
+ (void)stopNetLog;
+ (void)setNetworkThreadPriority:(double)a0;
+ (struct stream_engine { void *x0; void *x1; } *)getGlobalEngine;
+ (id)getGlobalMetricsDeltas;
+ (void)enableTestCertVerifierForTesting;
+ (void)setMockCertVerifierForTesting:(struct unique_ptr<net::CertVerifier, std::default_delete<net::CertVerifier>> { struct __compressed_pair<net::CertVerifier *, std::default_delete<net::CertVerifier>> { struct CertVerifier *x0; } x0; })a0;
+ (void)setHostResolverRulesForTesting:(id)a0;
+ (void)preventStrippingCronetBidirectionalStream;
+ (void)preventStrippingNativeCronetModules;
+ (unsigned long long)getMetricsMapSize;
+ (void)initialize;
+ (void)start;
+ (void)setMetricsEnabled:(BOOL)a0;
+ (void)startInternal;

@end
