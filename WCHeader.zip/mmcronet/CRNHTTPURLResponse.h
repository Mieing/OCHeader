@class NSString;

@interface CRNHTTPURLResponse : NSHTTPURLResponse {
    NSString *_cr_HTTPVersion;
}

- (id)cr_HTTPVersion;
- (void).cxx_destruct;
- (id)initWithURL:(id)a0 statusCode:(long long)a1 HTTPVersion:(id)a2 headerFields:(id)a3;

@end
