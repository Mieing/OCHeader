@interface EmptyNSURLCache : NSURLCache

+ (id)emptyNSURLCache;

- (id)cachedResponseForRequest:(id)a0;

@end
