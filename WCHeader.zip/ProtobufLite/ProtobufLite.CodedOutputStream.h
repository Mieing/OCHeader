@interface ProtobufLite.CodedOutputStream : _TtCs12_SwiftObject {
    void /* unknown type, empty encoding */ pos;
    void /* unknown type, empty encoding */ available;
}

@end
