@interface ProtobufLite.CodedInputStream : _TtCs12_SwiftObject {
    void /* unknown type, empty encoding */ pos;
    void /* unknown type, empty encoding */ available;
    void /* unknown type, empty encoding */ lastTag;
    void /* unknown type, empty encoding */ recursionDepth;
    void /* unknown type, empty encoding */ recursionLimit;
}

@end
