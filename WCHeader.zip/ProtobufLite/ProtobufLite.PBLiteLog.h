@interface ProtobufLite.PBLiteLog : _TtCs12_SwiftObject

@end
