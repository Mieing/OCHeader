@interface ProtobufLite.Message : _TtCs12_SwiftObject {
    void /* unknown type, empty encoding */ hasBits;
    void /* unknown type, empty encoding */ cacheSize;
    void /* unknown type, empty encoding */ packedMemoizedSerializedSize;
}

@end
