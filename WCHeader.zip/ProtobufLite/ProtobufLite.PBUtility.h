@interface ProtobufLite.PBUtility : _TtCs12_SwiftObject

@end
