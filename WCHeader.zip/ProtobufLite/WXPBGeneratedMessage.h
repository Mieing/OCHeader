@class GamePbRequestMsgInfo;

@interface WXPBGeneratedMessage : NSObject <NSCopying> {
    int has_bits_[3];
    int _serializedSize;
    struct PBClassInfo { BOOL x0; unsigned int x1; id x2; unsigned long long *x3; unsigned long long *x4; struct *x5; } *_classInfo;
    id *_ivarValueDict;
}

@property (retain, nonatomic) GamePbRequestMsgInfo *pbRequestMsgInfo;

+ (id)modelContainerPropertyMappingForConfigTag:(id)a0;
+ (id)parseFromJSONObject:(id)a0;
+ (id)parseFromJSONString:(id)a0;
+ (id)newInitializedInstance;
+ (id)parseFromData:(id)a0;

- (id)gcToJsonStr;
- (id)getAndCreateMsgInfoIfNeed;
- (BOOL)isRespSuccess;
- (void)setBaseRequest:(id)a0;
- (id)baseResponse;
- (unsigned int)continueFlag;
- (BOOL)hadIncloudeUnKnownField;
- (id)toJSONString;
- (BOOL)parseJSONValue:(const void *)a0;
- (int)computeValueSize:(id)a0 fieldNumber:(int)a1 fieldType:(unsigned char)a2;
- (int)computeValueSizeNoTag:(id)a0 fieldType:(unsigned char)a1;
- (id)debugDescription2;
- (int)indexOfPropertyWithGetter:(const char *)a0;
- (int)indexOfPropertyWithSetter:(const char *)a0;
- (void)initRequiredField;
- (BOOL)isMessageInitialized:(id)a0;
- (id)mergeFromCodedInputData:(struct CodedInputData { char *x0; int x1; int x2; int x3; int x4; int x5; int x6; int x7; int x8; } *)a0;
- (BOOL)mergeFromJSONObject:(id)a0;
- (BOOL)mergeFromJSONString:(id)a0;
- (id)parseJSONValue:(const void *)a0 fieldInfo:(struct { int x0; unsigned char x1; unsigned char x2; BOOL x3; int x4; char *x5; union { void *x0; char *x1; Class x2; void /* function */ *x3; } x6; } *)a1;
- (id)readValueFromCodedInputData:(struct CodedInputData { char *x0; int x1; int x2; int x3; int x4; int x5; int x6; int x7; int x8; } *)a0 fieldType:(unsigned char)a1;
- (void *)toJSONValue:(void *)a0;
- (void *)toJSONValue:(void *)a0 value:(id)a1 fieldType:(unsigned char)a2;
- (void)writeToCodedOutputData:(struct CodedOutputData { char *x0; unsigned long long x1; int x2; } *)a0;
- (void)writeValueToCodedOutputData:(struct CodedOutputData { char *x0; unsigned long long x1; int x2; } *)a0 value:(id)a1 fieldNumber:(int)a2 fieldType:(unsigned char)a3;
- (void)writeValueToCodedOutputDataNoTag:(struct CodedOutputData { char *x0; unsigned long long x1; int x2; } *)a0 value:(id)a1 fieldType:(unsigned char)a2;
- (void)clear;
- (void)setValue:(id)a0 atIndex:(int)a1;
- (id)serializedData;
- (id)init;
- (BOOL)hasProperty:(int)a0;
- (id)valueAtIndex:(int)a0;
- (void)observeValueForKeyPath:(id)a0 ofObject:(id)a1 change:(id)a2 context:(void *)a3;
- (void)dealloc;
- (id)debugDescription;
- (id)copyWithZone:(struct _NSZone { } *)a0;
- (BOOL)isInitialized;
- (int)serializedSize;
- (BOOL)mergeFromData:(id)a0;
- (id)toJSONObject;

@end
