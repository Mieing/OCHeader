@class NSString, NSMutableArray;

@interface FinderPoiStreamTabList_FinderPoiStreamTabItem : WXPBGeneratedMessage

@property (nonatomic) unsigned int tabId;
@property (retain, nonatomic) NSString *wording;
@property (retain, nonatomic) NSMutableArray *filter;

+ (void)initialize;

@end
