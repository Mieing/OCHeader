@interface KSUPnPXMLFixer : NSObject

+ (id)fixedXMLData:(id)a0;
+ (id)fixedTagName:(id)a0;

@end
