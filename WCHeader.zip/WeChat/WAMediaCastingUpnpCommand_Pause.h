@interface WAMediaCastingUpnpCommand_Pause : WAMediaCastingUpnpCommand

+ (id)command;

- (id)init;
- (id)commandXMLBodyString;

@end
