@interface WeAPMApiCodecReaderWriter : FlutterStandardReaderWriter

- (id)writerWithData:(id)a0;
- (id)readerWithData:(id)a0;

@end
