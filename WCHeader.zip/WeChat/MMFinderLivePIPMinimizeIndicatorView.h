@interface MMFinderLivePIPMinimizeIndicatorView : UIView

@property (copy, nonatomic) id /* block */ layoutBlock;

- (void)layoutSubviews;
- (void).cxx_destruct;

@end
