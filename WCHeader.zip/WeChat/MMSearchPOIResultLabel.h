@interface MMSearchPOIResultLabel : MMUILabel

- (void)setResultText:(id)a0 WithHighlightKey:(id)a1;
- (void)setResultText:(id)a0 Prefix:(id)a1 WithHighlightKey:(id)a2;
- (void)setResultText:(id)a0 WithHighlightKey:(id)a1 HighlightColor:(id)a2;
- (void)setResultText:(id)a0 Prefix:(id)a1 WithHighlightKey:(id)a2 HighlightColor:(id)a3;

@end
