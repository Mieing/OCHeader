@interface WAJSEventHandler_operateAudio : WAJSEventHandler_BaseEvent

- (void)handleJSEvent:(id)a0;

@end
