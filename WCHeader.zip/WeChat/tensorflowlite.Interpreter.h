@interface tensorflowlite.Interpreter : _TtCs12_SwiftObject {
    void /* unknown type, empty encoding */ options;
    void /* unknown type, empty encoding */ delegates;
    void /* unknown type, empty encoding */ cInterpreter;
    void /* unknown type, empty encoding */ cXNNPackDelegate;
}

@end
