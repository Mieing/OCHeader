@class NSString, NSMutableArray;

@interface EXTPKG_mmpayapplynfccardbo_CardPasskitInfo : WXPBGeneratedMessage

@property (retain, nonatomic) NSString *cardTitle;
@property (retain, nonatomic) NSString *encryptScheme;
@property (retain, nonatomic) NSMutableArray *cardPasskitShowContent;

+ (void)initialize;

@end
