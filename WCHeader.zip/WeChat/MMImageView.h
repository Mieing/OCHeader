@protocol imageViewDelegate;

@interface MMImageView : MMUIImageView

@property (weak, nonatomic) id<imageViewDelegate> m_delegate;

- (void)touchesBegan:(id)a0 withEvent:(id)a1;
- (void)touchesMoved:(id)a0 withEvent:(id)a1;
- (void)touchesEnded:(id)a0 withEvent:(id)a1;
- (void)touchesCancelled:(id)a0 withEvent:(id)a1;
- (void).cxx_destruct;

@end
