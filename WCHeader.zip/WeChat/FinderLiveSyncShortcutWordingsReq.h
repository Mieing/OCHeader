@interface FinderLiveSyncShortcutWordingsReq : WXPBGeneratedMessage

+ (void)initialize;

@end
