@interface WAJSEventHandler_setStorageAsync : WAJSEventHandler_setStorage

- (void)handleJSEvent:(id)a0;
- (void)innerHandleJSEvent:(id)a0;

@end
