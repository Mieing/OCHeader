@interface Coordinate : WXPBGeneratedMessage

@property (nonatomic) double x;
@property (nonatomic) double y;

+ (void)initialize;

@end
