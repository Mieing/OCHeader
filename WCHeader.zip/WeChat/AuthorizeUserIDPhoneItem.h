@class NSString;

@interface AuthorizeUserIDPhoneItem : WXPBGeneratedMessage

@property (retain, nonatomic) NSString *phoneId;
@property (retain, nonatomic) NSString *showPhone;
@property (retain, nonatomic) NSString *bankType;

+ (void)initialize;

@end
