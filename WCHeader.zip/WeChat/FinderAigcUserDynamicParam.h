@class NSMutableArray;

@interface FinderAigcUserDynamicParam : WXPBGeneratedMessage

@property (retain, nonatomic) NSMutableArray *paramItems;

+ (void)initialize;

@end
