@class NSString;

@interface AppSetting : WXPBGeneratedMessage

@property (retain, nonatomic) NSString *appId;
@property (nonatomic) unsigned int appFlag;
@property (retain, nonatomic) NSString *openId;

+ (void)initialize;

@end
