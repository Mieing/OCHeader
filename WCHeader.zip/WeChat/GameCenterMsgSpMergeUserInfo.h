@class NSString;

@interface GameCenterMsgSpMergeUserInfo : WXPBGeneratedMessage

@property (retain, nonatomic) NSString *avatarUrl;

+ (void)initialize;

@end
