@interface ContactsItemCell : MMTableViewCell

- (void)setBackgroundColor:(id)a0;

@end
