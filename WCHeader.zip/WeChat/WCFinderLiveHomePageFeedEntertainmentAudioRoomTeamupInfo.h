@class NSString, WCFinderContact;

@interface WCFinderLiveHomePageFeedEntertainmentAudioRoomTeamupInfo : NSObject

@property (retain, nonatomic) WCFinderContact *contact;
@property (retain, nonatomic) NSString *sdkUserId;
@property (nonatomic) unsigned long long statusFlag;

- (BOOL)isEqual:(id)a0;
- (void).cxx_destruct;

@end
