@interface ScanLicenceUtillity : NSObject

+ (id)GetBankNumberAreaImage:(id)a0 cardInfo:(void *)a1;

@end
