@class NSString, UIImage, NSData;

@interface WCBizImageBrowseItem : NSObject

@property (retain, nonatomic) NSString *m_nsImgUrl;
@property (retain, nonatomic) UIImage *m_nsThumbImage;
@property (retain, nonatomic) NSData *m_ndImgData;

- (void)dealloc;
- (void).cxx_destruct;

@end
