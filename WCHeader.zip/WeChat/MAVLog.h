@interface MAVLog : NSObject

+ (void)initialize;
+ (void)info:(id)a0;
+ (void)debug:(id)a0;
+ (void)warning:(id)a0;
+ (void)error:(id)a0;

@end
