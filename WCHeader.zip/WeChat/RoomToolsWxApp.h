@class NSString;

@interface RoomToolsWxApp : WXPBGeneratedMessage

@property (retain, nonatomic) NSString *username;
@property (retain, nonatomic) NSString *path;

+ (void)initialize;

@end
