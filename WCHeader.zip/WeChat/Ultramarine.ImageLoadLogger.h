@interface Ultramarine.ImageLoadLogger : _TtCs12_SwiftObject

@end
