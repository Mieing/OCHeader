@interface WeChat.MBEventHandler_notifyFireworkPlayEnd : MBEventHandlerBaseAsync

- (id)apiName;
- (void)invoke:(id)a0;
- (id)init;

@end
