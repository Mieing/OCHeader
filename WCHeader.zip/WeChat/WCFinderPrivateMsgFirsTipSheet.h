@interface WCFinderPrivateMsgFirsTipSheet : WCFinderCustomPanelSheet

- (id)init;
- (id)loadContentView;
- (void)clickLinkAction;

@end
