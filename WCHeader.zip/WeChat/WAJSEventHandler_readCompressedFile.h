@interface WAJSEventHandler_readCompressedFile : WAJSEventHandler_BaseEvent

- (void)handleJSEvent:(id)a0;
- (void)innerHandleJSEven:(id)a0;

@end
