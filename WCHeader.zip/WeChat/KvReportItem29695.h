@class NSString;

@interface KvReportItem29695 : KvReportBaseItem

@property (nonatomic) unsigned int bizObject;
@property (nonatomic) unsigned int actionType;
@property (copy, nonatomic) NSString *bizContent;

- (unsigned int)reportKvId;
- (id)reportOrderedFieldNameArr;
- (void).cxx_destruct;

@end
