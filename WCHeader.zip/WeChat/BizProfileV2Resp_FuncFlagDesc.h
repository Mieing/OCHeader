@class NSString;

@interface BizProfileV2Resp_FuncFlagDesc : WXPBGeneratedMessage

@property (nonatomic) unsigned int funcFlag;
@property (retain, nonatomic) NSString *wording;
@property (retain, nonatomic) NSString *jumpUrl;

+ (void)initialize;

@end
