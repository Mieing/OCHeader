@class NSString;

@interface WebviewJSEventHandler_uploadImage : WebviewJSEventHandlerBase <IWebviewResourceManagerExt> {
    BOOL _isShowProgressTips;
}

@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

@end
