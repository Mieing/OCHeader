@class NSString;

@interface MMFinderLiveAttackGiftCacheInfo : MMFinderLiveGiftResCacheInfo

@property (retain, nonatomic) NSString *path;

- (void).cxx_destruct;

@end
