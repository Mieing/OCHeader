@class NSString;

@interface YtExtraOptions : NSObject

@property (retain, nonatomic) NSString *bussiness_id;
@property (retain, nonatomic) NSString *person_id;
@property (retain, nonatomic) NSString *person_type;
@property (retain, nonatomic) NSString *req_type;
@property (retain, nonatomic) NSString *mp_business_buffer;

- (void).cxx_destruct;

@end
