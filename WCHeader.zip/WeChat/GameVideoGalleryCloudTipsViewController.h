@interface GameVideoGalleryCloudTipsViewController : GameVideoBottomTipsViewController

- (void)setupContentView:(id)a0;

@end
