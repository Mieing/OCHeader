@class NSString;

@interface TextStatePublishJSApiJumpInfo : NSObject

@property (retain, nonatomic) NSString *type;
@property (retain, nonatomic) NSString *buf;

- (void).cxx_destruct;

@end
