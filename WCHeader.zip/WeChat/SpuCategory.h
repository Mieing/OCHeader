@interface SpuCategory : WXPBGeneratedMessage

@property (nonatomic) unsigned long long level1Id;
@property (nonatomic) unsigned long long level2Id;
@property (nonatomic) unsigned long long level3Id;

+ (void)initialize;

@end
