@class NSString;

@interface PushLoginMsg : NSObject

@property (retain, nonatomic) NSString *url;

- (id)initWithXML:(id)a0;
- (void)dealloc;
- (void)parseXML:(id)a0;
- (void).cxx_destruct;

@end
