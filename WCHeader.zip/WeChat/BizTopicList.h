@class NSString, NSMutableArray;

@interface BizTopicList : WXPBGeneratedMessage

@property (retain, nonatomic) NSString *title;
@property (retain, nonatomic) NSMutableArray *topic;

+ (void)initialize;

@end
