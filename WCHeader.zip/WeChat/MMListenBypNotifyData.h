@interface MMListenBypNotifyData : WXPBGeneratedMessage

@property (nonatomic) unsigned long long syncId;

+ (void)initialize;

@end
