@class FTSMsgSearchResultHandler;

@interface FTSMsgSearchResultHandlerWrapper : NSObject

@property (weak, nonatomic) FTSMsgSearchResultHandler *handler;

- (void).cxx_destruct;

@end
