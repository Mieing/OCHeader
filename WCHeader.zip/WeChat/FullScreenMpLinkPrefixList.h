@class NSArray;

@interface FullScreenMpLinkPrefixList : NSObject

@property (retain, nonatomic) NSArray *mpLinkPrefixes;

- (id)init;
- (id)initWithMpLinkPrefixes:(id)a0;
- (void).cxx_destruct;

@end
