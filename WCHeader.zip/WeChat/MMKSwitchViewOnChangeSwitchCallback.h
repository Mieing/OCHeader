@interface MMKSwitchViewOnChangeSwitchCallback : NSObject {
    struct Handle<std::shared_ptr<kinda::KSwitchViewOnChangeSwitchCallback>> { struct shared_ptr<kinda::KSwitchViewOnChangeSwitchCallback> { struct KSwitchViewOnChangeSwitchCallback *__ptr_; struct __shared_weak_count *__cntrl_; } m_obj; } _cppRefHandle;
}

- (id)initWithCpp:(const void *)a0;
- (void)onChangeSwitch;
- (void).cxx_destruct;
- (id).cxx_construct;

@end
