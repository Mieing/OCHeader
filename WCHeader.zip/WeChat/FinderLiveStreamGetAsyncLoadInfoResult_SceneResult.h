@interface FinderLiveStreamGetAsyncLoadInfoResult_SceneResult : WXPBGeneratedMessage

@property (nonatomic) unsigned int scene;
@property (nonatomic) int result;

+ (void)initialize;

@end
