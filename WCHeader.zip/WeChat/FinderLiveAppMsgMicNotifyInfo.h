@class NSString;

@interface FinderLiveAppMsgMicNotifyInfo : WXPBGeneratedMessage

@property (retain, nonatomic) NSString *micSdkUserId;
@property (nonatomic) int scene;

+ (void)initialize;

@end
