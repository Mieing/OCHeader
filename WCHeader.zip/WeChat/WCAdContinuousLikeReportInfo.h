@interface WCAdContinuousLikeReportInfo : NSObject

@property (nonatomic) unsigned int totalLikeCount;
@property (nonatomic) unsigned int continuousLikeCount;
@property (nonatomic) unsigned int bannerPlayCount;

@end
