@interface WCPayDecimalNoActionKeyboardView : WCPayDecimalKeyboardView

- (void)setupKeyboardView;
- (void)layoutButtonForNoAction;
- (void)layoutKeyboardButton;
- (double)commonBtnWidth;
- (double)commonBtnHeight;

@end
