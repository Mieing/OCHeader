@class BaseResponse;

@interface FinderLiveUpdateQuestionCardInfoResp : WXPBGeneratedMessage

@property (retain, nonatomic) BaseResponse *baseResponse;

+ (void)initialize;

@end
