@class NSString;

@interface HomePageTheme_TopBanner : WXPBGeneratedMessage

@property (retain, nonatomic) NSString *picUrl;
@property (retain, nonatomic) NSString *jumpUrl;
@property (nonatomic) unsigned int id;
@property (retain, nonatomic) NSString *externInfo;

+ (void)initialize;

@end
