@interface WCFinderRedPacketVideoEditCropRectModel : NSObject

@property (nonatomic) double topPercent;
@property (nonatomic) double leftPercent;
@property (nonatomic) double widthPercent;
@property (nonatomic) double heightPercent;

- (id)init;
- (id)description;

@end
