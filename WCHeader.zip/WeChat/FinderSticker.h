@interface FinderSticker : WXPBGeneratedMessage

@property (nonatomic) unsigned int desuin;

+ (void)initialize;

@end
