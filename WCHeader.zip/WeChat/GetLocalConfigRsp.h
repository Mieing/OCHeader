@class NSString;

@interface GetLocalConfigRsp : WXPBGeneratedMessage

@property (retain, nonatomic) NSString *configValue;

+ (void)initialize;

@end
