@class NSString, NSData;

@interface FinderLiveProductLikeResponse : WXPBGeneratedMessage

@property (retain, nonatomic) NSString *errmsg;
@property (retain, nonatomic) NSData *newestProductBuffer;

+ (void)initialize;

@end
