@class NSString;

@interface DelOpenIMKefuContactReq : WXPBGeneratedMessage

@property (retain, nonatomic) NSString *kfUsername;

+ (void)initialize;

@end
