@interface FinderReddotExposeBuff : WXPBGeneratedMessage

@property (nonatomic) unsigned long long objectId;

+ (void)initialize;

@end
