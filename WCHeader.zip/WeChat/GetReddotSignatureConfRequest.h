@class BaseRequest;

@interface GetReddotSignatureConfRequest : WXPBGeneratedMessage

@property (retain, nonatomic) BaseRequest *baseRequest;

+ (void)initialize;

@end
