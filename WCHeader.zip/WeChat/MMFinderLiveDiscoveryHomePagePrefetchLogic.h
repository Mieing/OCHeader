@interface MMFinderLiveDiscoveryHomePagePrefetchLogic : NSObject

+ (void)prefetchIfNeeded:(id)a0;
+ (void)_prefetchWithParams:(id)a0;
+ (id)createKaraReddotContextWithCtrlInfo:(id)a0 extInfo:(id)a1;

@end
