@interface MMLiveBeautyMouthMorphDriver : MMLiveBeautyDriver

- (void)apply;
- (void)teardown;

@end
