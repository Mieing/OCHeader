@class NSMutableArray;

@interface FinderLiveNewBattleTeamInfo : WXPBGeneratedMessage

@property (retain, nonatomic) NSMutableArray *members;
@property (nonatomic) unsigned long long rewardWecoin;
@property (nonatomic) unsigned int result;
@property (nonatomic) unsigned long long count;

+ (void)initialize;

@end
