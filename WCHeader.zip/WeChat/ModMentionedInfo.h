@interface ModMentionedInfo : WXPBGeneratedMessage

@property (nonatomic) unsigned long long objectId;
@property (nonatomic) unsigned int opType;

+ (void)initialize;

@end
