@interface WAJSEventHandler_preloadWebStore : WAJSEventHandler_BaseEvent

- (void)handleJSEvent:(id)a0;

@end
