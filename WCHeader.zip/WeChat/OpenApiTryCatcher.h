@interface OpenApiTryCatcher : NSObject

+ (void)openURL:(id)a0 options:(id)a1 completionHandler:(id /* block */)a2;
+ (void)safeOpenApiOpenUrl:(id)a0;
+ (void)safeApplicationOpenUrl:(id)a0;

@end
