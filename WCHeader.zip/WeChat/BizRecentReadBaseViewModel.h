@class NSString;

@interface BizRecentReadBaseViewModel : MMObject

@property (nonatomic) unsigned int readTime;
@property (retain, nonatomic) NSString *title;

- (void).cxx_destruct;

@end
