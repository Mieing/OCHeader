@class NSData;

@interface FinderLiveExtInfo : WXPBGeneratedMessage

@property (retain, nonatomic) NSData *anchorStatusBuffer;

+ (void)initialize;

- (void)setAnchorStatusBuffer:(id)a0;
- (id)anchorStatusBuffer;

@end
