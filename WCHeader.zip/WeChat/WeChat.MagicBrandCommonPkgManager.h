@interface WeChat.MagicBrandCommonPkgManager : WeChat.MBBootsPkgManagementBiz {
    void /* unknown type, empty encoding */ bizName;
}

- (id)initWithInstanceName:(id)a0;
- (void).cxx_destruct;

@end
