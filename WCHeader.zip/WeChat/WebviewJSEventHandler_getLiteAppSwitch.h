@interface WebviewJSEventHandler_getLiteAppSwitch : WebviewJSEventHandlerBase

- (void)handleJSEvent:(id)a0 HandlerFacade:(id)a1 ExtraData:(id)a2;

@end
