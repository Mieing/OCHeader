@interface DataReportRelatedDataCollector : NSObject

+ (id)collectViewData:(id)a0 target:(id)a1;
+ (id)collectPageData:(id)a0 target:(id)a1;
+ (id)getValidPageWithContextNotNil:(id)a0;
+ (id)getValidPageWithContext:(id)a0;
+ (id)getRelatedViews:(id)a0;

@end
