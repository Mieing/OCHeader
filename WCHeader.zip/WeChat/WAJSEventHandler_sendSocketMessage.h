@interface WAJSEventHandler_sendSocketMessage : WAJSEventHandler_BaseEvent

- (void)handleJSEvent:(id)a0;

@end
