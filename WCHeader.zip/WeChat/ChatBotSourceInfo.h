@class NSString;

@interface ChatBotSourceInfo : WXPBGeneratedMessage

@property (nonatomic) unsigned long long updateTime;
@property (retain, nonatomic) NSString *sourceName;

+ (void)initialize;

@end
