@interface MMHelpAndFeedbackViewController : MMWebViewController

- (void)viewDidLoad;
- (void)updateRightBarButtonWithContextId:(id)a0;
- (void)onUplog:(id)a0;
- (void)setIsForceFullScreen:(BOOL)a0;

@end
