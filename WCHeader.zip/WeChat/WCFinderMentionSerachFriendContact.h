@class NSString, WCFinderContact;

@interface WCFinderMentionSerachFriendContact : NSObject

@property (retain, nonatomic) WCFinderContact *finderContact;
@property (retain, nonatomic) NSString *matchDesc;
@property (retain, nonatomic) NSString *highlightDesc;

- (void).cxx_destruct;

@end
