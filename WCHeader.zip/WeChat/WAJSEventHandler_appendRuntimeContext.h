@interface WAJSEventHandler_appendRuntimeContext : WAJSEventHandler_BaseEvent

- (void)handleJSEvent:(id)a0;

@end
