@class NSString, NSMutableArray;

@interface WCFinderFeedGroupSection2 : NSObject

@property (retain, nonatomic) NSString *section;
@property (retain, nonatomic) NSMutableArray *items;

- (id)initWithName:(id)a0;
- (void).cxx_destruct;

@end
