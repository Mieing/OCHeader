@class LiveTRTCDelayInfo;

@interface LiveAudioSEIData : WXPBGeneratedMessage

@property (nonatomic) long long wxT;
@property (retain, nonatomic) LiveTRTCDelayInfo *trtcDelayInfo;

+ (void)initialize;

@end
