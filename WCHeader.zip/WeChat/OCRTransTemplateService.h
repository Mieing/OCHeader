@interface OCRTransTemplateService : WSTemplateBaseMgr

- (void)onServiceInit;
- (id)defaultTemplateZipPath;
- (id)templateResouceRootPath;
- (unsigned int)packageResouceType;
- (unsigned long long)localJSBizType;

@end
