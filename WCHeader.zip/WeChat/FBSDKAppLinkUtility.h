@interface FBSDKAppLinkUtility : NSObject

+ (void)fetchDeferredAppLink:(id /* block */)a0;
+ (id)appInvitePromotionCodeFromURL:(id)a0;

@end
