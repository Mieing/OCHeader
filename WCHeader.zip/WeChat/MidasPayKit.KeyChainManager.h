@interface MidasPayKit.KeyChainManager : _TtCs12_SwiftObject {
    void /* unknown type, empty encoding */ service;
    void /* unknown type, empty encoding */ accessGroup;
    void /* unknown type, empty encoding */ serialQueue;
    void /* unknown type, empty encoding */ $__lazy_storage_$_bundleSeedID;
    void /* unknown type, empty encoding */ shouldStoredTypeUseGroup;
}

@end
