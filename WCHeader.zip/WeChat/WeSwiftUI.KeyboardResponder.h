@interface WeSwiftUI.KeyboardResponder : _TtCs12_SwiftObject {
    void /* unknown type, empty encoding */ _currentHeight;
    void /* unknown type, empty encoding */ animationDuration;
    void /* unknown type, empty encoding */ cancellable;
}

@end
