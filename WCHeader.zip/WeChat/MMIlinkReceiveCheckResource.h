@class NSString;

@interface MMIlinkReceiveCheckResource : NSObject

@property (retain, nonatomic) NSString *resourceName;
@property (nonatomic) unsigned int resourceVersion;

- (void).cxx_destruct;

@end
