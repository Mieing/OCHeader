@class NSString;

@interface FinderJumpInfo_HotBubbleStyle : WXPBGeneratedMessage

@property (retain, nonatomic) NSString *iconUrl;
@property (retain, nonatomic) NSString *wording;
@property (retain, nonatomic) NSString *recommendReason;

+ (void)initialize;

@end
