@interface MMTextRestrictNumberHandler : MMTextRestrictRule

- (void)textDidChange:(id)a0;

@end
