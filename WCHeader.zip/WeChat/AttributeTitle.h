@class AttributeTitle_Content;

@interface AttributeTitle : WXPBGeneratedMessage

@property (retain, nonatomic) AttributeTitle_Content *content;

+ (void)initialize;

- (void)setContent:(id)a0;
- (id)content;

@end
