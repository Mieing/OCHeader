@interface WeChat.LiveSkeletonLog : _TtCs12_SwiftObject

@end
