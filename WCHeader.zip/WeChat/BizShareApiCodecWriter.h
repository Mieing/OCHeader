@interface BizShareApiCodecWriter : FlutterStandardWriter

- (void)writeValue:(id)a0;

@end
