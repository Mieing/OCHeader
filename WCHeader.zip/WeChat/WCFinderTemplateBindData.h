@class WCFinderTemplatePublishParams;

@interface WCFinderTemplateBindData : NSObject

@property (retain, nonatomic) WCFinderTemplatePublishParams *params;
@property (nonatomic) BOOL isOnlyPreview;

- (void).cxx_destruct;

@end
