@interface QSpotFollowCameraLight : QCommonLight

@end
