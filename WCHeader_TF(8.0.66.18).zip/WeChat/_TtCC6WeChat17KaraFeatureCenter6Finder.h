@interface _TtCC6WeChat17KaraFeatureCenter6Finder : _TtCC6WeChat17KaraFeatureCenter9Component <WeChat.IKaraFinderExt> {
    void /* unknown type, empty encoding */ postHistoryTable;
}

- (void)onEnterFinderPostView:(id)a0;
- (void)onPostFinder:(id)a0;

@end
