@interface WeAppCore.MagicAdMiniProgramLog : _TtCs12_SwiftObject

@end
