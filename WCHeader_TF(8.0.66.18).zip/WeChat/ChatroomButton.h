@class JumpInfo;

@interface ChatroomButton : WXPBGeneratedMessage

@property (retain, nonatomic) JumpInfo *buttonJumpInfo;

+ (void)initialize;

@end
