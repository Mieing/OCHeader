@class NSString, BaseResponse;

@interface FinderLiveNewAcceptPkResponse : WXPBGeneratedMessage

@property (retain, nonatomic) BaseResponse *baseResponse;
@property (retain, nonatomic) NSString *sessionId;

+ (void)initialize;

@end
