@class NSMutableArray;

@interface FinderLiveEcGetLiveConfigResponse_ShowAnimation_ShoppingBagOptions : WXPBGeneratedMessage

@property (nonatomic) BOOL showMarketingContent;
@property (nonatomic) unsigned int delayTime;
@property (nonatomic) unsigned int carouselInterval;
@property (retain, nonatomic) NSMutableArray *contentUrl;

+ (void)initialize;

@end
