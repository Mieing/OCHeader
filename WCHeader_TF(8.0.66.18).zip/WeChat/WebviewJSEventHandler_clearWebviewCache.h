@interface WebviewJSEventHandler_clearWebviewCache : WebviewJSEventHandlerBase

- (void)handleJSEvent:(id)a0 HandlerFacade:(id)a1 ExtraData:(id)a2;

@end
