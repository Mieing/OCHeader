@class NSString;

@interface SdkUIContext : WXPBGeneratedMessage

@property (retain, nonatomic) NSString *pageId;
@property (retain, nonatomic) NSString *viewId;

+ (void)initialize;

@end
