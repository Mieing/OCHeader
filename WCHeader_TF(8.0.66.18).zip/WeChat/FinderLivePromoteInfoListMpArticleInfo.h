@class NSString;

@interface FinderLivePromoteInfoListMpArticleInfo : WXPBGeneratedMessage

@property (retain, nonatomic) NSString *title;
@property (retain, nonatomic) NSString *description;
@property (retain, nonatomic) NSString *thumbUrl;
@property (retain, nonatomic) NSString *url;
@property (retain, nonatomic) NSString *authorName;

+ (void)initialize;

@end
