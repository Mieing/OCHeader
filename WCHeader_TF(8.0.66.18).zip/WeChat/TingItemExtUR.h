@class NSString;

@interface TingItemExtUR : WXPBGeneratedMessage

@property (retain, nonatomic) NSString *extInfo;
@property (nonatomic) long long playIndex;
@property (nonatomic) long long fromScene;
@property (nonatomic) BOOL withFloatBall;
@property (retain, nonatomic) NSString *singerCategoryId;

+ (void)initialize;

@end
