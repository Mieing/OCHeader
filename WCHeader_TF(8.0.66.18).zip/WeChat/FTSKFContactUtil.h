@interface FTSKFContactUtil : NSObject

+ (void)pushToKFContactMsgContent:(id)a0 currentNavController:(id)a1;

@end
