@interface FinderObjectBulletCommentCtrl : WXPBGeneratedMessage

@property (nonatomic) BOOL shortVideoNeedFetchBulletComment;

+ (void)initialize;

- (void)setShortVideoNeedFetchBulletComment:(BOOL)a0;
- (BOOL)shortVideoNeedFetchBulletComment;

@end
