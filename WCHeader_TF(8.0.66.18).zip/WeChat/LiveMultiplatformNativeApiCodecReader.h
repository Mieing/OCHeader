@interface LiveMultiplatformNativeApiCodecReader : FlutterStandardReader

- (id)readValueOfType:(unsigned char)a0;

@end
