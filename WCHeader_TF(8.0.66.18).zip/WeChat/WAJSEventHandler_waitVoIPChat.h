@interface WAJSEventHandler_waitVoIPChat : WAJSEventHandler_BaseEvent

- (void)handleJSEvent:(id)a0;
- (id)init;

@end
