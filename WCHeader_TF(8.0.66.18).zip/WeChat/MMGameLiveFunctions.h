@interface MMGameLiveFunctions : NSObject

+ (BOOL)canGameButtonHighLightedByTeamupWith:(id)a0;

@end
