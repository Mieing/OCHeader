@interface MMFinderLiveSongSettingOperationNavBar : MMFinderLiveMusicSettingOperationNavBar

- (id)createOperationBar;
- (id)getCurrentLeftButton;
- (id)getCurrentRightView;

@end
