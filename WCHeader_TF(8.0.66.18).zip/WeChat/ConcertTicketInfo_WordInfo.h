@class NSString;

@interface ConcertTicketInfo_WordInfo : WXPBGeneratedMessage

@property (retain, nonatomic) NSString *content;

+ (void)initialize;

@end
