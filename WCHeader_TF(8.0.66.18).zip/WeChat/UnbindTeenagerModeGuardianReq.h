@class BaseRequest, NSString;

@interface UnbindTeenagerModeGuardianReq : WXPBGeneratedMessage

@property (retain, nonatomic) BaseRequest *baseRequest;
@property (retain, nonatomic) NSString *guardianUserName;

+ (void)initialize;

@end
