@interface WAJSEventHandler_getVolume : WAJSEventHandler_BaseEvent

- (void)handleJSEvent:(id)a0;

@end
