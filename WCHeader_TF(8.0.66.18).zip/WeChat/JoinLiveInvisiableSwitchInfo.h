@interface JoinLiveInvisiableSwitchInfo : WXPBGeneratedMessage

@property (nonatomic) unsigned int canShowSwitch;
@property (nonatomic) unsigned int isEnable;

+ (void)initialize;

@end
