@interface FinderModHelpPromotionSetting : WXPBGeneratedMessage

@property (nonatomic) unsigned int opType;
@property (nonatomic) unsigned long long objectId;

+ (void)initialize;

@end
