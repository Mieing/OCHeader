@interface EcsGiftResendGiftInLiveLogicFlutterViewController : MMFlutterViewController

+ (id)createViewControllerWithParams:(id)a0;
+ (id)finderPresentInfoJsonFromPB:(id)a0;

- (void)dealloc;
- (BOOL)shouldInteractiveDismiss;
- (void)viewDidLoad;
- (void)viewDidAppear:(BOOL)a0;
- (void)viewDidDisappear:(BOOL)a0;

@end
