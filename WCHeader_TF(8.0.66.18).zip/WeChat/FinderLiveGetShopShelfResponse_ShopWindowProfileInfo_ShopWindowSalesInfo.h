@class NSMutableArray;

@interface FinderLiveGetShopShelfResponse_ShopWindowProfileInfo_ShopWindowSalesInfo : WXPBGeneratedMessage

@property (nonatomic) unsigned int showSalesFlag;
@property (retain, nonatomic) NSMutableArray *salesItems;

+ (void)initialize;

@end
