@interface FinderLiveRelatedListReadStat : WXPBGeneratedMessage

@property (nonatomic) unsigned long long objectId;

+ (void)initialize;

@end
