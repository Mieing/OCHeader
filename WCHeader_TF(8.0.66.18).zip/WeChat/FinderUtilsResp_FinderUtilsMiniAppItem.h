@class NSString;

@interface FinderUtilsResp_FinderUtilsMiniAppItem : WXPBGeneratedMessage

@property (retain, nonatomic) NSString *title;

+ (void)initialize;

@end
