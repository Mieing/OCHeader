@interface GameCenterMsgUtil : MMObject

@end
