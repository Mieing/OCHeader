@class MMScrollStack;

@interface MMStackViewController : MMUIViewController

@property (retain, nonatomic) MMScrollStack *stackView;

- (void)viewDidLoad;
- (void)initStackView;
- (void)initUIDebug;
- (void).cxx_destruct;

@end
