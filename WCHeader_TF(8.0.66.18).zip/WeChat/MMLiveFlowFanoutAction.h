@interface MMLiveFlowFanoutAction : MMLiveFlowLinearDelegatingActionBase

- (void)invokeWithInput:(id)a0 flowInvocationContext:(id)a1 actionInvocationContext:(id)a2 completionBlock:(id /* block */)a3;

@end
