@interface WAErrorCodeRecord : NSObject

@property (nonatomic) unsigned long long errCode;
@property (nonatomic) unsigned long long timestampMS;

@end
