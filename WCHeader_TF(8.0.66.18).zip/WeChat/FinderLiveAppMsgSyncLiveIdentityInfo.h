@class FinderLiveAliasInfo;

@interface FinderLiveAppMsgSyncLiveIdentityInfo : WXPBGeneratedMessage

@property (retain, nonatomic) FinderLiveAliasInfo *targetLiveAliasInfo;
@property (nonatomic) unsigned int targetLiveIdentity;

+ (void)initialize;

@end
