@interface EcsWxaVipDiscountReq_ProductDiscountInfo : WXPBGeneratedMessage

@property (nonatomic) unsigned long long productId;
@property (nonatomic) unsigned long long skuId;
@property (nonatomic) unsigned long long vipDiscountedPrice;

+ (void)initialize;

@end
