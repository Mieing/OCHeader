@class NSString, NSMutableArray;

@interface RightCorner : WXPBGeneratedMessage

@property (retain, nonatomic) NSMutableArray *menuNodeList;
@property (retain, nonatomic) NSString *title;

+ (void)initialize;

@end
