@interface F2FDoodleActionPoint : WXPBGeneratedMessage

@property (nonatomic) unsigned long long timestamp;
@property (nonatomic) unsigned int pointSeq;
@property (nonatomic) float left;
@property (nonatomic) float top;

+ (void)initialize;

@end
