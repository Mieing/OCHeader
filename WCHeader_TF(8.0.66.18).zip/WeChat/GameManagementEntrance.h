@class NSString;

@interface GameManagementEntrance : WXPBGeneratedMessage

@property (retain, nonatomic) NSString *jumpUrl;

+ (void)initialize;

@end
