@class NSString;

@interface MMListenMusicInfo_UserShare : WXPBGeneratedMessage

@property (retain, nonatomic) NSString *cover;

+ (void)initialize;

@end
