@interface WeChat.LiteAppPackageUtil : NSObject

+ (id)checkPackageIntegrityWithAppId:(id)a0 patchId:(id)a1 md5:(id)a2;
+ (id)checkBaseLibIntegrityWithInfo:(id)a0;

- (id)init;
- (void).cxx_destruct;

@end
