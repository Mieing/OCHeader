@interface SKBuiltinUint64_t : WXPBGeneratedMessage

@property (nonatomic) unsigned long long ullVal;

+ (void)initialize;

@end
