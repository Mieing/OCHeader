@interface FinderFlashSaleSetting : WXPBGeneratedMessage

@property (nonatomic) unsigned int nonDstFlashSaleSwitch;
@property (nonatomic) unsigned int flashSaleFirstOpenFlag;

+ (void)initialize;

@end
