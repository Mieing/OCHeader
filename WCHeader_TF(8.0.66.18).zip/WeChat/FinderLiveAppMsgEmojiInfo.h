@class NSString, NSData;

@interface FinderLiveAppMsgEmojiInfo : WXPBGeneratedMessage

@property (retain, nonatomic) NSString *emojiMd5;
@property (retain, nonatomic) NSData *emoticonBuffer;

+ (void)initialize;

@end
