@class NSString;

@interface FinderJumpOnlineHelpParams : WXPBGeneratedMessage

@property (retain, nonatomic) NSString *username;

+ (void)initialize;

@end
