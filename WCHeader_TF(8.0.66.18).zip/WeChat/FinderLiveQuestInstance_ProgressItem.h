@interface FinderLiveQuestInstance_ProgressItem : WXPBGeneratedMessage

@property (nonatomic) unsigned long long accomplishedCount;
@property (nonatomic) unsigned int commTargetType;
@property (nonatomic) unsigned int targetRangeType;
@property (nonatomic) unsigned int accomplishedCountType;

+ (void)initialize;

@end
