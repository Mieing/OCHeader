@interface WAMediaCastingUpnpCommand_Play : WAMediaCastingUpnpCommand

+ (id)command;

- (id)init;
- (id)commandXMLBodyString;

@end
