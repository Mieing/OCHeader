@interface MMLiveTaskMgrService : NSObject

@property (class, retain, nonatomic) Class externalIMP;

@end
