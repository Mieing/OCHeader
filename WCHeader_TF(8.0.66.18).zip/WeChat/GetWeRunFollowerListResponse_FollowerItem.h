@class NSString;

@interface GetWeRunFollowerListResponse_FollowerItem : WXPBGeneratedMessage

@property (retain, nonatomic) NSString *username;
@property (nonatomic) BOOL isFollowed;

+ (void)initialize;

@end
