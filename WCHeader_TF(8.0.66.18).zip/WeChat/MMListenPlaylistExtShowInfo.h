@interface MMListenPlaylistExtShowInfo : WXPBGeneratedMessage

@property (nonatomic) BOOL hasVoiceReview;
@property (nonatomic) BOOL hasReview;
@property (nonatomic) BOOL enableAddReview;

+ (void)initialize;

@end
