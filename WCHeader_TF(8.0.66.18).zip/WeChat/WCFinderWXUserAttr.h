@class NSString;

@interface WCFinderWXUserAttr : NSObject

@property (nonatomic, getter=shouldShowEnterTips) BOOL showEnterTips;
@property (copy, nonatomic) NSString *enterTips;

- (id)initWithAttr:(id)a0;
- (id)description;
- (void).cxx_destruct;

@end
