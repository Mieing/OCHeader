@interface WNRTEAttributeListInfo : NSObject <NSCopying>

@property (nonatomic) unsigned int headIndex;
@property (nonatomic) unsigned int index;

- (id)copyWithZone:(struct _NSZone { } *)a0;

@end
