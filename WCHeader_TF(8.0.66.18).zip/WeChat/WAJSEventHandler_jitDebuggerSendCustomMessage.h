@interface WAJSEventHandler_jitDebuggerSendCustomMessage : WAJSEventHandler_BaseEvent

- (void)handleJSEvent:(id)a0;

@end
