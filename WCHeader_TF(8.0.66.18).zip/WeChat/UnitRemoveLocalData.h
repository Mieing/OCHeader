@interface UnitRemoveLocalData : NSObject

+ (void)remove:(id)a0 instance:(id)a1 param:(id)a2 error:(id *)a3;

@end
