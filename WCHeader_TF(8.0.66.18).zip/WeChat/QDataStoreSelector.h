@class NSString;

@interface QDataStoreSelector : NSObject

@property (copy, nonatomic) NSString *name;

- (id)table;
- (id)keyForTileColumn:(id)a0;
- (void).cxx_destruct;

@end
