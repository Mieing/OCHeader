@interface WAJSEventHandler_listenLoadSubPackageTaskStateChange : WAJSEventHandler_BaseEvent

- (void)handleJSEvent:(id)a0;
- (id)init;

@end
