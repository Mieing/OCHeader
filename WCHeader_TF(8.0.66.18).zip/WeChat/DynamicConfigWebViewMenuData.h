@interface DynamicConfigWebViewMenuData : CustomWebViewMenuData

@end
