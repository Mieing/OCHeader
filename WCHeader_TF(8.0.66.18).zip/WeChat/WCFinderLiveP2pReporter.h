@interface WCFinderLiveP2pReporter : NSObject

+ (void)reportCurrentP2pStatWithLiveTask:(id)a0;

@end
