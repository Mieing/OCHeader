@interface WCFinderNativeDramaDetailCGIParams : NSObject

@property (nonatomic) unsigned long long dramaId;
@property (nonatomic) unsigned long long fromObjectId;
@property (nonatomic) int consumerMode;

@end
