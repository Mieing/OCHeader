@class NSString, FinderJumpInfo;

@interface FinderLiveAppMsgLiveRoomCommentTopAreaMsgInfo : WXPBGeneratedMessage

@property (nonatomic) unsigned int bizType;
@property (retain, nonatomic) NSString *content;
@property (retain, nonatomic) FinderJumpInfo *jumpInfo;

+ (void)initialize;

@end
