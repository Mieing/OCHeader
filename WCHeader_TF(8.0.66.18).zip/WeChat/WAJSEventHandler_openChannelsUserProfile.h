@interface WAJSEventHandler_openChannelsUserProfile : WAJSEventHandler_BaseEvent

- (void)handleJSEvent:(id)a0;
- (void)popOpenSDKTransferMMWebviewVC:(id)a0;

@end
