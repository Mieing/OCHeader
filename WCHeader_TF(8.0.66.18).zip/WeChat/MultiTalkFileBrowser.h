@class NSString;

@interface MultiTalkFileBrowser : WCFileBrowser

@property (retain, nonatomic) NSString *chatName;

- (id)initWithChatName:(id)a0;
- (void)viewDidLoad;
- (void)viewWillAppear:(BOOL)a0;
- (void).cxx_destruct;

@end
