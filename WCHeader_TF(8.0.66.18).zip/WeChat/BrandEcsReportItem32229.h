@class NSString;

@interface BrandEcsReportItem32229 : WXPBGeneratedMessage

@property (retain, nonatomic) NSString *sessionId;
@property (retain, nonatomic) NSString *bizUserName;
@property (nonatomic) unsigned long long clientTimeStampMs;
@property (nonatomic) int actionType;
@property (retain, nonatomic) NSString *element;
@property (retain, nonatomic) NSString *elementType;
@property (retain, nonatomic) NSString *elementId;
@property (retain, nonatomic) NSString *feedsId;
@property (retain, nonatomic) NSString *pos;
@property (nonatomic) unsigned int elementStayTime;
@property (retain, nonatomic) NSString *exInfo1;
@property (retain, nonatomic) NSString *exInfo2;
@property (retain, nonatomic) NSString *exInfo3;
@property (retain, nonatomic) NSString *exInfo4;
@property (retain, nonatomic) NSString *exInfo5;
@property (retain, nonatomic) NSString *exInfo6;

+ (void)initialize;

@end
