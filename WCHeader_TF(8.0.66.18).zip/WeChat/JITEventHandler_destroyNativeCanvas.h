@interface JITEventHandler_destroyNativeCanvas : JITEventHandlerBaseAsync

- (id)apiName;
- (void)invoke:(id)a0;

@end
