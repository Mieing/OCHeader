@class WCPayWalletEntryHeaderView;

@interface WCPayWalletEntrySectionHeader : UICollectionReusableView

@property (retain, nonatomic) WCPayWalletEntryHeaderView *entryView;

- (void)layoutSubviews;
- (void).cxx_destruct;

@end
