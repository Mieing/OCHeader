@interface WeVisRfxPagMgr : NSObject

+ (void)registerLogger;

@end
