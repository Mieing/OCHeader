@interface LocalJSEventHandler_getFTSHotData : LocalJSEventHandler_BaseEvent

- (void)handleJSEvent:(id)a0;

@end
