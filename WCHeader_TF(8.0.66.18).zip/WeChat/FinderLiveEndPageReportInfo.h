@class NSData;

@interface FinderLiveEndPageReportInfo : WXPBGeneratedMessage

@property (retain, nonatomic) NSData *extInfo;

+ (void)initialize;

@end
