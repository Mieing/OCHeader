@interface LiteAppJsApiEmoticonPostedFinish : LiteAppJsApi

- (void)invokeJsApi:(id)a0 param:(id)a1 isFromView:(BOOL)a2;

@end
