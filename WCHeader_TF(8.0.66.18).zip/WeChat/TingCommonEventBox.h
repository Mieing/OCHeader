@interface TingCommonEventBox : NSObject

@property (nonatomic) unsigned long long value;

- (id)initWithValue:(unsigned long long)a0;

@end
