@class NSMutableArray;

@interface NewLifeGetLatestPostingFeedResp : WXPBGeneratedMessage

@property (retain, nonatomic) NSMutableArray *feedList;

+ (void)initialize;

@end
