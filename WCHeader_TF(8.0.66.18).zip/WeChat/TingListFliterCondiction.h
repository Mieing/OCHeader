@class NSMutableArray;

@interface TingListFliterCondiction : WXPBGeneratedMessage

@property (nonatomic) int listOrderType;
@property (retain, nonatomic) NSMutableArray *topListenCtx;

+ (void)initialize;

@end
