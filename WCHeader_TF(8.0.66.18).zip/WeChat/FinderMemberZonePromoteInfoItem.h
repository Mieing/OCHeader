@class NSString;

@interface FinderMemberZonePromoteInfoItem : WXPBGeneratedMessage

@property (retain, nonatomic) NSString *title;
@property (retain, nonatomic) NSString *subTitle;

+ (void)initialize;

@end
