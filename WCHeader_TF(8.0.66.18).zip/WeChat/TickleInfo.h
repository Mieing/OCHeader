@class NSString;

@interface TickleInfo : WXPBGeneratedMessage

@property (nonatomic) BOOL isTickle;
@property (retain, nonatomic) NSString *toUsername;

+ (void)initialize;

@end
