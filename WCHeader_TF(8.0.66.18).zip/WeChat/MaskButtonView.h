@class MMUIView;

@interface MaskButtonView : MMUIButton

@property (retain, nonatomic) MMUIView *maskButtonHighlightedView;

- (void)layoutSubviews;
- (void)setHighlighted:(BOOL)a0;
- (void).cxx_destruct;

@end
