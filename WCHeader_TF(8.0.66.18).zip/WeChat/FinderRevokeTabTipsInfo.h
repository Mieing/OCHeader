@class NSString, NSMutableArray;

@interface FinderRevokeTabTipsInfo : WXPBGeneratedMessage

@property (retain, nonatomic) NSString *tabTipsRevokeId;
@property (retain, nonatomic) NSMutableArray *tabTipsInfo;

+ (void)initialize;

@end
