@interface NewLifeNativePostConfig : WXPBGeneratedMessage

@property (nonatomic) BOOL ignoreDraft;

+ (void)initialize;

@end
