@interface WAJSEventHandler_insertVideoPlayer : WAJSEventHandler_BaseEvent

- (void)handleJSEvent:(id)a0;

@end
