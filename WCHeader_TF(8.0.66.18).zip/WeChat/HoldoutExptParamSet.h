@class NSMutableArray;

@interface HoldoutExptParamSet : WXPBGeneratedMessage

@property (retain, nonatomic) NSMutableArray *holdoutItems;

+ (void)initialize;

- (void)setHoldoutItems:(id)a0;
- (id)holdoutItems;

@end
