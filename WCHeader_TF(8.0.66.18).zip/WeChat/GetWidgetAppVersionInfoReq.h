@class BaseRequest;

@interface GetWidgetAppVersionInfoReq : WXPBGeneratedMessage

@property (retain, nonatomic) BaseRequest *baseRequest;

+ (void)initialize;

@end
