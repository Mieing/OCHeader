@class NSString;

@interface LocalResource : WXPBGeneratedMessage

@property (retain, nonatomic) NSString *resourceName;
@property (nonatomic) unsigned int resourceVersion;

+ (void)initialize;

@end
