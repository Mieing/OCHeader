@interface WCAdShakeGetCardIdResultModel : WCAdChannelReportExtendInfoModel

@property (nonatomic) int result;
@property (nonatomic) int encoreShake;

@end
