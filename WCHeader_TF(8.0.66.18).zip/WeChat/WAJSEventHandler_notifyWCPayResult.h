@interface WAJSEventHandler_notifyWCPayResult : WAJSEventHandler_BaseEvent

- (void)handleJSEvent:(id)a0;

@end
