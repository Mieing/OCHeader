@class NSString, NSMutableArray;

@interface FinderNegativeFeedback : WXPBGeneratedMessage

@property (retain, nonatomic) NSMutableArray *notInterestedWordingList;
@property (retain, nonatomic) NSString *negativeFeedbackTitle;

+ (void)initialize;

@end
