@class NSString;

@interface FinderJumpCreateWxStatusParams : WXPBGeneratedMessage

@property (retain, nonatomic) NSString *iconId;
@property (retain, nonatomic) NSString *description;
@property (retain, nonatomic) NSString *sourceId;

+ (void)initialize;

@end
