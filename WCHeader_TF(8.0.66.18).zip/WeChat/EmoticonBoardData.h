@class NSMutableArray;

@interface EmoticonBoardData : NSObject

@property (retain, nonatomic) NSMutableArray *boardPageWraps;
@property (retain, nonatomic) NSMutableArray *tabItems;

- (void).cxx_destruct;

@end
