@interface QBaseReportCofig : NSObject

@property (nonatomic) BOOL beaconEnable;
@property (nonatomic) BOOL beaconLogEnable;

@end
