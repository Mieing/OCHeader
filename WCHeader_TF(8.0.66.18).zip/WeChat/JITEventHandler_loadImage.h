@interface JITEventHandler_loadImage : JITEventHandlerBaseAsync

- (id)apiName;
- (void)invoke:(id)a0;

@end
