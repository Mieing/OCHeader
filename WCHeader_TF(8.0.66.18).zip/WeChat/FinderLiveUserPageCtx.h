@interface FinderLiveUserPageCtx : WXPBGeneratedMessage

@property (nonatomic) unsigned long long lastId;
@property (nonatomic) unsigned int pageNum;

+ (void)initialize;

@end
