@interface path_provider_foundation.PathProviderPlugin : NSObject <FlutterPlugin>

+ (void)registerWithRegistrar:(id)a0;

- (id)init;

@end
