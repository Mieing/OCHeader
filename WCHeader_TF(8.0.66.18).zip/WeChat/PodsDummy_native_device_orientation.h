@interface PodsDummy_native_device_orientation : NSObject

@end
