@class UIColor;

@interface WCFinderFeedSubCommentCellStyleConfig : NSObject

@property (nonatomic) double avatarLeftMargin;
@property (retain, nonatomic) UIColor *customBackgroundColor;

+ (id)defaultConfig;

- (void).cxx_destruct;

@end
