@class NSString;

@interface WXGRoamDownloadSessionInfo : NSObject

@property (copy, nonatomic) NSString *userName;
@property (nonatomic) unsigned long long sessionSize;

- (void).cxx_destruct;

@end
