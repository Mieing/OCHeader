@class NSMutableArray;

@interface ChatRoamFileEncKeyList : WXPBGeneratedMessage

@property (retain, nonatomic) NSMutableArray *encList;

+ (void)initialize;

@end
