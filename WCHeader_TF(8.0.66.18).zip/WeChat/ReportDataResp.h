@class BaseResponse;

@interface ReportDataResp : WXPBGeneratedMessage

@property (retain, nonatomic) BaseResponse *baseResponse;

+ (void)initialize;

@end
