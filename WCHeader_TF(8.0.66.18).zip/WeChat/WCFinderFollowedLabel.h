@interface WCFinderFollowedLabel : UILabel

- (struct CGSize { double x0; double x1; })intrinsicContentSize;

@end
