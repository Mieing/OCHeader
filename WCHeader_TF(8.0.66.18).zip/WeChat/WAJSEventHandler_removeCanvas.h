@interface WAJSEventHandler_removeCanvas : WAJSEventHandler_BaseEvent

- (void)handleJSEvent:(id)a0;

@end
