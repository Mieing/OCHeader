@class NSMutableArray;

@interface FinderLiveHotCommentAnimationInfoList : WXPBGeneratedMessage

@property (retain, nonatomic) NSMutableArray *animationList;

+ (void)initialize;

@end
