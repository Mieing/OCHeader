@interface PoiRate : WXPBGeneratedMessage

@property (nonatomic) float rate;
@property (nonatomic) float taste;
@property (nonatomic) float service;
@property (nonatomic) float decoration;

+ (void)initialize;

@end
