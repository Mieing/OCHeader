@interface WeChat.WSNativeHotListAISearchData : _TtCs12_SwiftObject {
    void /* unknown type, empty encoding */ title;
    void /* unknown type, empty encoding */ pos;
    void /* unknown type, empty encoding */ scene;
    void /* unknown type, empty encoding */ requestId;
    void /* unknown type, empty encoding */ session;
    void /* unknown type, empty encoding */ config;
    void /* unknown type, empty encoding */ hideSearchBar;
    void /* unknown type, empty encoding */ hideNavBar;
    void /* unknown type, empty encoding */ extParms;
    void /* unknown type, empty encoding */ businessType;
    void /* unknown type, empty encoding */ type;
}

@end
