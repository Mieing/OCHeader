@interface WCLiveReplayScrollActionSheetItem : MMScrollActionSheetItem

- (id)init;

@end
