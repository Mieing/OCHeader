@class NSMutableArray;

@interface FinderLiveModShelfRemoveProductCmd : WXPBGeneratedMessage

@property (retain, nonatomic) NSMutableArray *removeProductIds;
@property (retain, nonatomic) NSMutableArray *items;

+ (void)initialize;

@end
