@interface WAJSEventHandler_exitChatTool : WAJSEventHandler_BaseEvent

- (void)handleJSEvent:(id)a0;
- (id)init;

@end
