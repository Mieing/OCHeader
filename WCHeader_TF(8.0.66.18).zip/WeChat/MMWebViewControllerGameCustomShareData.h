@class NSNumber, NSString, UIImage;

@interface MMWebViewControllerGameCustomShareData : NSObject

@property (retain, nonatomic) NSNumber *buttonId;
@property (copy, nonatomic) NSString *buttonTitle;
@property (copy, nonatomic) UIImage *buttonImage;

- (void).cxx_destruct;

@end
