@class NSMutableArray;

@interface AppStorePreloadControl : WXPBGeneratedMessage

@property (retain, nonatomic) NSMutableArray *infoList;

+ (void)initialize;

@end
