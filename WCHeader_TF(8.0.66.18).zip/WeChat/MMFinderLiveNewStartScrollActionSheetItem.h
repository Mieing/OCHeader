@class NSString;

@interface MMFinderLiveNewStartScrollActionSheetItem : MMScrollActionSheetItem

@property (nonatomic) long long reportElementId;
@property (retain, nonatomic) NSString *redDotPath;

- (id)init;
- (void).cxx_destruct;

@end
