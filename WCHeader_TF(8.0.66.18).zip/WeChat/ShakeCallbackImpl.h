@interface ShakeCallbackImpl : NSObject

+ (id)createShakeCallback:(id)a0;

@end
