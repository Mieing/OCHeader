@class RoamData;

@interface UpdateRoamDataReq_AddReq : WXPBGeneratedMessage

@property (retain, nonatomic) RoamData *roamData;

+ (void)initialize;

@end
