@interface WCFinderDynamicWordingIconCreator : NSObject

+ (struct WCFinderDynamicIcon { id x0; id x1; })createLikeIconWithDataItem:(id)a0 likeFlag:(int)a1 iconSize:(double)a2 whiteColorWithAlpha:(id)a3;

@end
