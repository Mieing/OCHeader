@class NSString;

@interface WCPayTransferAmountReInputPageStruct : NSObject

@property (retain, nonatomic) NSString *title;
@property (retain, nonatomic) NSString *wording;

+ (id)GenFromDictionary:(id)a0;

- (void)genFromDic:(id)a0;
- (void).cxx_destruct;

@end
