@class NSMutableArray;

@interface FLTStatusUnRegisterCallbackCmdIdReq : WXPBGeneratedMessage

@property (retain, nonatomic) NSMutableArray *cmdIdList;

+ (void)initialize;

@end
