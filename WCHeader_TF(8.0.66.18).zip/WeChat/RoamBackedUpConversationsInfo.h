@class NSMutableArray;

@interface RoamBackedUpConversationsInfo : WXPBGeneratedMessage

@property (retain, nonatomic) NSMutableArray *conversationId;
@property (retain, nonatomic) NSMutableArray *size;

+ (void)initialize;

@end
