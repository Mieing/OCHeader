@class NSString;

@interface FinderSearchSuggestResponse_Suggestion : WXPBGeneratedMessage

@property (retain, nonatomic) NSString *suggest;
@property (retain, nonatomic) NSString *highlightSuggest;

+ (void)initialize;

@end
