@class NSMutableArray;

@interface FinderObjectOcrFrameInfo : WXPBGeneratedMessage

@property (retain, nonatomic) NSMutableArray *boxes;

+ (void)initialize;

- (void)setBoxes:(id)a0;
- (id)boxes;

@end
