@interface ReportCtrlInfo : WXPBGeneratedMessage

+ (void)initialize;

@end
