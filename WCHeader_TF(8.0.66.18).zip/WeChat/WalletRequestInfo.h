@class NSMutableArray;

@interface WalletRequestInfo : WXPBGeneratedMessage

@property (retain, nonatomic) NSMutableArray *array;

+ (void)initialize;

@end
