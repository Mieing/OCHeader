@interface WAJSEventHandler_setWebviewInputAccessoryViewHiddenState : WAJSEventHandler_BaseEvent

- (void)handleJSEvent:(id)a0;

@end
