@class NSString;

@interface FinderLiveRewardFreeGiftResponse_FailItem : WXPBGeneratedMessage

@property (retain, nonatomic) NSString *giftId;
@property (nonatomic) unsigned int failDetail;

+ (void)initialize;

@end
