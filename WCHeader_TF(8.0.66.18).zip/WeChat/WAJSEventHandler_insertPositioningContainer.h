@interface WAJSEventHandler_insertPositioningContainer : WAJSEventHandler_BaseEvent

- (void)handleJSEvent:(id)a0;

@end
