@class BaseRequest, NSMutableArray;

@interface GetMsgContactListReq : WXPBGeneratedMessage

@property (retain, nonatomic) BaseRequest *baseRequest;
@property (retain, nonatomic) NSMutableArray *reqList;

+ (void)initialize;

@end
