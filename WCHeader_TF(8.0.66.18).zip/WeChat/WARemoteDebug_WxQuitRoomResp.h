@class WARemoteDebug_BaseResp;

@interface WARemoteDebug_WxQuitRoomResp : WXPBGeneratedMessage

@property (retain, nonatomic) WARemoteDebug_BaseResp *baseResponse;

+ (void)initialize;

@end
