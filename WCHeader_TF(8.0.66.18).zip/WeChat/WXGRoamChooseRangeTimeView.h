@interface WXGRoamChooseRangeTimeView : MMPageSheetBaseView

- (id)init;
- (void)setupView;
- (void)showChooseRangeTimeDetailView;
- (void)onComplete;

@end
