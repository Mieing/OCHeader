@class FinderLiveCreatorFunctions;

@interface WCFinderLivePersonalCenterAccountServiceSectionInfo : NSObject

@property (nonatomic) unsigned long long type;
@property (retain, nonatomic) FinderLiveCreatorFunctions *functions;

- (void).cxx_destruct;

@end
