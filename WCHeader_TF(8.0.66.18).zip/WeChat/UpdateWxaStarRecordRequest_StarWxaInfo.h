@class NSString;

@interface UpdateWxaStarRecordRequest_StarWxaInfo : WXPBGeneratedMessage

@property (retain, nonatomic) NSString *username;
@property (nonatomic) unsigned int versionType;

+ (void)initialize;

@end
