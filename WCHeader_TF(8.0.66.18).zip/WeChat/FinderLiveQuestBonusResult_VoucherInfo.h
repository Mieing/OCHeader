@interface FinderLiveQuestBonusResult_VoucherInfo : WXPBGeneratedMessage

@property (nonatomic) unsigned long long value;

+ (void)initialize;

@end
