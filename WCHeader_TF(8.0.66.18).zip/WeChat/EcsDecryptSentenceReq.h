@class NSMutableArray;

@interface EcsDecryptSentenceReq : WXPBGeneratedMessage

@property (retain, nonatomic) NSMutableArray *wordList;

+ (void)initialize;

@end
