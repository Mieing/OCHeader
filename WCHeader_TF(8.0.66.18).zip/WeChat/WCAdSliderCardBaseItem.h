@class WCMediaItem;

@interface WCAdSliderCardBaseItem : NSObject <NSCoding>

@property (retain, nonatomic) WCMediaItem *mediaItem;

- (id)initWithCoder:(id)a0;
- (void)encodeWithCoder:(id)a0;
- (void).cxx_destruct;

@end
