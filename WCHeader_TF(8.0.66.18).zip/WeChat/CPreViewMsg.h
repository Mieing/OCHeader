@interface CPreViewMsg : CMessageWrap

+ (BOOL)isPreViewMsg;

@end
